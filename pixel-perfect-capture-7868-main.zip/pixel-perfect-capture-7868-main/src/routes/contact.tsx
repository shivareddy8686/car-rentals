import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Clock, Headset, Mail, MapPin, Phone } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { locationsQuery } from "@/lib/riderent";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact RideRent — Support, Bookings & Corporate Enquiries" },
      {
        name: "description",
        content:
          "Reach the RideRent team by phone, email or the enquiry form. 24/7 roadside support and same-day answers on bookings and corporate accounts.",
      },
      { property: "og:title", content: "Contact RideRent" },
      {
        property: "og:description",
        content: "Phone, email and branch contacts for bookings, support and partnerships.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactPage,
});

const topics = [
  { value: "booking", label: "A booking or reservation" },
  { value: "support", label: "Roadside or on-trip support" },
  { value: "documents", label: "Document verification" },
  { value: "corporate", label: "Corporate account" },
  { value: "other", label: "Something else" },
];

function ContactPage() {
  const locations = useQuery(locationsQuery);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [topic, setTopic] = useState("booking");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sending, setSending] = useState(false);

  function validate() {
    const next: Record<string, string> = {};
    if (name.trim().length < 2) next["name"] = "Please enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email))
      next["email"] = "Please enter a valid email address.";
    if (!/^[0-9+\-\s]{10,15}$/.test(phone))
      next["phone"] = "Please enter a valid phone number.";
    if (message.trim().length < 10)
      next["message"] = "Tell us a little more — at least 10 characters.";
    return next;
  }

  function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.keys(next).length > 0) return;
    setSending(true);
    window.setTimeout(() => {
      setSending(false);
      setName("");
      setEmail("");
      setPhone("");
      setMessage("");
      toast.success("Message sent", {
        description: "Our team replies within one working day.",
      });
    }, 700);
  }

  return (
    <>
      <section className="border-b border-border bg-sidebar text-sidebar-foreground">
        <div className="container-page py-12 md:py-16">
          <p className="eyebrow text-sidebar-foreground/60">Get in touch</p>
          <h1 className="mt-3 text-3xl font-extrabold md:text-5xl">Contact RideRent</h1>
          <p className="mt-4 max-w-2xl text-sidebar-foreground/75">
            Booking questions, licence verification or a breakdown on the road — reach the
            team any time.
          </p>
        </div>
      </section>

      <section className="section-y">
        <div className="container-page grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:items-start">
          <form
            onSubmit={handleSubmit}
            className="surface-panel space-y-5 p-6 md:p-8"
            aria-label="Contact form"
            noValidate
          >
            <h2 className="text-xl font-bold">Send us a message</h2>

            <div className="grid gap-5 sm:grid-cols-2">
              <Field id="name" label="Full name" error={errors["name"]}>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ananya Iyer"
                  aria-invalid={Boolean(errors["name"])}
                />
              </Field>
              <Field id="email" label="Email address" error={errors["email"]}>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  aria-invalid={Boolean(errors["email"])}
                />
              </Field>
              <Field id="phone" label="Phone number" error={errors["phone"]}>
                <Input
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  aria-invalid={Boolean(errors["phone"])}
                />
              </Field>
              <div className="space-y-1.5">
                <Label htmlFor="topic">What is this about?</Label>
                <Select value={topic} onValueChange={setTopic}>
                  <SelectTrigger id="topic">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {topics.map((item) => (
                      <SelectItem key={item.value} value={item.value}>
                        {item.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Field id="message" label="Message" error={errors["message"]}>
              <Textarea
                id="message"
                rows={6}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Tell us the city, dates and vehicle you have in mind."
                aria-invalid={Boolean(errors["message"])}
              />
            </Field>

            <Button type="submit" size="lg" disabled={sending}>
              {sending ? "Sending…" : "Send message"}
            </Button>
          </form>

          <div className="space-y-6">
            <div className="surface-panel space-y-4 p-6">
              <h2 className="text-lg font-semibold">Head office</h2>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex gap-2">
                  <MapPin className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                  RideRent HQ, 4th Floor, Orion Business Park, Baner Road, Pune 411045
                </li>
                <li className="flex gap-2">
                  <Phone className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                  <a href="tel:+912041005000" className="hover:text-foreground">
                    +91 20 4100 5000
                  </a>
                </li>
                <li className="flex gap-2">
                  <Mail className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                  <a href="mailto:hello@riderent.in" className="hover:text-foreground">
                    hello@riderent.in
                  </a>
                </li>
                <li className="flex gap-2">
                  <Clock className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                  Office hours 9:00 – 19:00, Monday to Saturday
                </li>
                <li className="flex gap-2">
                  <Headset className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                  Roadside assistance 24/7 on +91 90000 11122
                </li>
              </ul>
            </div>

            <div className="surface-panel space-y-4 p-6">
              <h2 className="text-lg font-semibold">Branch desks</h2>
              <ul className="space-y-3 text-sm">
                {(locations.data ?? []).map((location) => (
                  <li key={location.id} className="border-b border-border pb-3 last:border-0 last:pb-0">
                    <p className="font-semibold">
                      {location.city} — {location.branch_name}
                    </p>
                    <p className="text-muted-foreground">{location.contact_phone}</p>
                    <p className="text-muted-foreground">{location.contact_email}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function Field({
  id,
  label,
  error,
  children,
}: {
  id: string;
  label: string;
  error?: string | undefined;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      {children}
      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}
    </div>
  );
}
