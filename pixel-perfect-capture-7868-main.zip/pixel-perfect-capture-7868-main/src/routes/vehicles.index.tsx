import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { LayoutGrid, List, SlidersHorizontal } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { VehicleCard } from "@/components/site/VehicleCard";
import { EmptyState } from "@/components/site/EmptyState";
import {
  categoriesQuery,
  formatPrice,
  locationsQuery,
  vehiclesQuery,
  type Vehicle,
} from "@/lib/riderent";

type Search = {
  category?: string | undefined;
  location?: string | undefined;
};

export const Route = createFileRoute("/vehicles/")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    category: typeof search["category"] === "string" ? search["category"] : undefined,
    location: typeof search["location"] === "string" ? search["location"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Browse Rental Vehicles — RideRent Fleet & Daily Rates" },
      {
        name: "description",
        content:
          "Filter the RideRent fleet by type, brand, fuel, transmission, seats, city and price. Compare real specifications and daily rates before you book.",
      },
      { property: "og:title", content: "Browse Rental Vehicles — RideRent" },
      {
        property: "og:description",
        content:
          "Economy, sedan, SUV, luxury, electric and van rentals with transparent daily pricing.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: VehicleCatalogPage,
});

const sortOptions = [
  { value: "popular", label: "Most popular" },
  { value: "price-asc", label: "Price: low to high" },
  { value: "price-desc", label: "Price: high to low" },
  { value: "rating", label: "Highest rating" },
  { value: "newest", label: "Newest first" },
] as const;

const PAGE_SIZE = 9;

function sortVehicles(list: Vehicle[], sort: string) {
  const copy = [...list];
  switch (sort) {
    case "price-asc":
      return copy.sort((a, b) => a.price_per_day - b.price_per_day);
    case "price-desc":
      return copy.sort((a, b) => b.price_per_day - a.price_per_day);
    case "rating":
      return copy.sort((a, b) => b.rating - a.rating);
    case "newest":
      return copy.sort((a, b) => b.manufacturing_year - a.manufacturing_year);
    default:
      return copy.sort((a, b) => b.booking_count - a.booking_count);
  }
}

function VehicleCatalogPage() {
  const search = Route.useSearch();
  const vehicles = useQuery(vehiclesQuery);
  const categories = useQuery(categoriesQuery);
  const locations = useQuery(locationsQuery);

  const all = vehicles.data ?? [];
  const maxPrice = Math.max(6000, ...all.map((v) => v.price_per_day));

  const [term, setTerm] = useState("");
  const [category, setCategory] = useState(search.category ?? "any");
  const [location, setLocation] = useState(search.location ?? "any");
  const [brand, setBrand] = useState("any");
  const [fuel, setFuel] = useState("any");
  const [transmission, setTransmission] = useState("any");
  const [seats, setSeats] = useState("any");
  const [minRating, setMinRating] = useState("any");
  const [availableOnly, setAvailableOnly] = useState(false);
  const [price, setPrice] = useState<number>(maxPrice);
  const [sort, setSort] = useState<string>("popular");
  const [layout, setLayout] = useState<"grid" | "list">("grid");
  const [page, setPage] = useState(1);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const brands = useMemo(
    () => Array.from(new Set(all.map((v) => v.brand))).sort(),
    [all],
  );
  const fuels = useMemo(
    () => Array.from(new Set(all.map((v) => v.fuel_type))).sort(),
    [all],
  );

  const filtered = useMemo(() => {
    const query = term.trim().toLowerCase();
    const result = all.filter((v) => {
      if (
        query &&
        !`${v.name} ${v.brand} ${v.model}`.toLowerCase().includes(query)
      )
        return false;
      if (category !== "any" && v.vehicle_categories?.slug !== category) return false;
      if (location !== "any" && v.locations?.slug !== location) return false;
      if (brand !== "any" && v.brand !== brand) return false;
      if (fuel !== "any" && v.fuel_type !== fuel) return false;
      if (transmission !== "any" && v.transmission !== transmission) return false;
      if (seats !== "any" && v.seats < Number(seats)) return false;
      if (minRating !== "any" && v.rating < Number(minRating)) return false;
      if (availableOnly && v.status !== "available") return false;
      if (v.price_per_day > price) return false;
      return true;
    });
    return sortVehicles(result, sort);
  }, [
    all,
    term,
    category,
    location,
    brand,
    fuel,
    transmission,
    seats,
    minRating,
    availableOnly,
    price,
    sort,
  ]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const current = Math.min(page, pageCount);
  const visible = filtered.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE);

  function reset() {
    setTerm("");
    setCategory("any");
    setLocation("any");
    setBrand("any");
    setFuel("any");
    setTransmission("any");
    setSeats("any");
    setMinRating("any");
    setAvailableOnly(false);
    setPrice(maxPrice);
    setPage(1);
  }

  return (
    <>
      <section className="border-b border-border bg-sidebar text-sidebar-foreground">
        <div className="container-page py-12 md:py-16">
          <p className="eyebrow text-sidebar-foreground/60">Our fleet</p>
          <h1 className="mt-3 text-3xl font-extrabold md:text-5xl">
            Browse every vehicle
          </h1>
          <p className="mt-4 max-w-2xl text-sidebar-foreground/75">
            {all.length} vehicles across five cities. Filter by type, budget, fuel and
            transmission to find the ride that fits your trip.
          </p>
        </div>
      </section>

      <section className="section-y">
        <div className="container-page grid gap-8 lg:grid-cols-[280px_1fr]">
          <div>
            <Button
              variant="outline"
              className="w-full lg:hidden"
              onClick={() => setFiltersOpen((v) => !v)}
              aria-expanded={filtersOpen}
            >
              <SlidersHorizontal className="size-4" aria-hidden="true" />
              {filtersOpen ? "Hide filters" : "Show filters"}
            </Button>

            <aside
              aria-label="Vehicle filters"
              className={`surface-panel mt-3 space-y-5 p-5 lg:mt-0 lg:block ${
                filtersOpen ? "block" : "hidden"
              }`}
            >
              <div className="flex items-center justify-between">
                <h2 className="text-base font-semibold">Filters</h2>
                <Button variant="ghost" size="sm" onClick={reset}>
                  Reset
                </Button>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="filter-search">Search</Label>
                <Input
                  id="filter-search"
                  placeholder="Brand or model"
                  value={term}
                  onChange={(e) => {
                    setTerm(e.target.value);
                    setPage(1);
                  }}
                />
              </div>

              <FilterSelect
                id="filter-type"
                label="Vehicle type"
                value={category}
                onChange={(v) => {
                  setCategory(v);
                  setPage(1);
                }}
                anyLabel="All types"
                options={(categories.data ?? []).map((c) => ({
                  value: c.slug,
                  label: c.name,
                }))}
              />

              <FilterSelect
                id="filter-brand"
                label="Brand"
                value={brand}
                onChange={(v) => {
                  setBrand(v);
                  setPage(1);
                }}
                anyLabel="All brands"
                options={brands.map((b) => ({ value: b, label: b }))}
              />

              <div className="space-y-2">
                <Label htmlFor="filter-price">
                  Max price per day: {formatPrice(price)}
                </Label>
                <Slider
                  id="filter-price"
                  min={500}
                  max={maxPrice}
                  step={100}
                  value={[price]}
                  onValueChange={([value]) => {
                    setPrice(value ?? maxPrice);
                    setPage(1);
                  }}
                />
              </div>

              <FilterSelect
                id="filter-fuel"
                label="Fuel type"
                value={fuel}
                onChange={(v) => {
                  setFuel(v);
                  setPage(1);
                }}
                anyLabel="Any fuel"
                options={fuels.map((f) => ({ value: f, label: f }))}
              />

              <FilterSelect
                id="filter-transmission"
                label="Transmission"
                value={transmission}
                onChange={(v) => {
                  setTransmission(v);
                  setPage(1);
                }}
                anyLabel="Any transmission"
                options={[
                  { value: "Automatic", label: "Automatic" },
                  { value: "Manual", label: "Manual" },
                ]}
              />

              <FilterSelect
                id="filter-seats"
                label="Minimum seats"
                value={seats}
                onChange={(v) => {
                  setSeats(v);
                  setPage(1);
                }}
                anyLabel="Any capacity"
                options={[
                  { value: "4", label: "4+ seats" },
                  { value: "5", label: "5+ seats" },
                  { value: "7", label: "7+ seats" },
                ]}
              />

              <FilterSelect
                id="filter-location"
                label="Pickup city"
                value={location}
                onChange={(v) => {
                  setLocation(v);
                  setPage(1);
                }}
                anyLabel="All cities"
                options={(locations.data ?? []).map((l) => ({
                  value: l.slug,
                  label: `${l.city} — ${l.branch_name}`,
                }))}
              />

              <FilterSelect
                id="filter-rating"
                label="Rating"
                value={minRating}
                onChange={(v) => {
                  setMinRating(v);
                  setPage(1);
                }}
                anyLabel="Any rating"
                options={[
                  { value: "4.5", label: "4.5 and above" },
                  { value: "4", label: "4.0 and above" },
                  { value: "3.5", label: "3.5 and above" },
                ]}
              />

              <div className="flex items-center gap-2 pt-1">
                <Checkbox
                  id="filter-available"
                  checked={availableOnly}
                  onCheckedChange={(checked) => {
                    setAvailableOnly(checked === true);
                    setPage(1);
                  }}
                />
                <Label htmlFor="filter-available" className="font-normal">
                  Available now only
                </Label>
              </div>
            </aside>
          </div>

          <div>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm text-muted-foreground">
                Showing <span className="font-semibold text-foreground">{visible.length}</span> of{" "}
                {filtered.length} vehicles
              </p>
              <div className="flex items-center gap-2">
                <Select value={sort} onValueChange={setSort}>
                  <SelectTrigger className="w-[190px]" aria-label="Sort vehicles">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {sortOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="hidden rounded-lg border border-border p-1 sm:flex">
                  <Button
                    variant={layout === "grid" ? "secondary" : "ghost"}
                    size="icon"
                    aria-label="Grid view"
                    onClick={() => setLayout("grid")}
                  >
                    <LayoutGrid className="size-4" />
                  </Button>
                  <Button
                    variant={layout === "list" ? "secondary" : "ghost"}
                    size="icon"
                    aria-label="List view"
                    onClick={() => setLayout("list")}
                  >
                    <List className="size-4" />
                  </Button>
                </div>
              </div>
            </div>

            {vehicles.isLoading ? (
              <div className="mt-6 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                {Array.from({ length: 6 }).map((_, index) => (
                  <Skeleton key={index} className="h-96 rounded-2xl" />
                ))}
              </div>
            ) : visible.length === 0 ? (
              <div className="mt-6">
                <EmptyState
                  title="No vehicles match those filters"
                  description="Try widening your budget, changing the city or clearing a filter or two."
                  action={
                    <Button variant="outline" onClick={reset}>
                      Clear filters
                    </Button>
                  }
                />
              </div>
            ) : (
              <div
                className={
                  layout === "grid"
                    ? "mt-6 grid gap-6 md:grid-cols-2 xl:grid-cols-3"
                    : "mt-6 flex flex-col gap-6"
                }
              >
                {visible.map((vehicle) => (
                  <VehicleCard key={vehicle.id} vehicle={vehicle} layout={layout} />
                ))}
              </div>
            )}

            {pageCount > 1 ? (
              <nav
                aria-label="Pagination"
                className="mt-10 flex items-center justify-center gap-2"
              >
                <Button
                  variant="outline"
                  size="sm"
                  disabled={current === 1}
                  onClick={() => setPage(current - 1)}
                >
                  Previous
                </Button>
                {Array.from({ length: pageCount }).map((_, index) => (
                  <Button
                    key={index}
                    variant={current === index + 1 ? "default" : "outline"}
                    size="sm"
                    aria-current={current === index + 1 ? "page" : undefined}
                    onClick={() => setPage(index + 1)}
                  >
                    {index + 1}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  disabled={current === pageCount}
                  onClick={() => setPage(current + 1)}
                >
                  Next
                </Button>
              </nav>
            ) : null}

            <p className="mt-10 text-sm text-muted-foreground">
              Looking for something specific?{" "}
              <Link to="/contact" className="font-semibold text-foreground underline">
                Ask our team
              </Link>{" "}
              and we will check upcoming returns for you.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

function FilterSelect({
  id,
  label,
  value,
  onChange,
  anyLabel,
  options,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  anyLabel: string;
  options: { value: string; label: string }[];
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger id={id}>
          <SelectValue placeholder={anyLabel} />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="any">{anyLabel}</SelectItem>
          {options.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
