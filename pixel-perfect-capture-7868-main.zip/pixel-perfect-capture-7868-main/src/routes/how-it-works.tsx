import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BadgeCheck,
  CalendarCheck,
  CarFront,
  ClipboardCheck,
  CreditCard,
  KeyRound,
  MapPin,
  RotateCcw,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      { title: "How Renting Works — Documents, Deposit & Pickup | RideRent" },
      {
        name: "description",
        content:
          "A step-by-step guide to renting with RideRent: choose dates, verify your licence, confirm the booking, collect the vehicle and return it without surprises.",
      },
      { property: "og:title", content: "How Renting Works — RideRent" },
      {
        property: "og:description",
        content:
          "Eight clear steps from search to return, plus what documents and deposit you need.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HowItWorksPage,
});

const steps = [
  {
    icon: MapPin,
    title: "Choose city and dates",
    body: "Pick the branch you want to collect from, the branch you will return to, and the exact days of your trip.",
  },
  {
    icon: CarFront,
    title: "Pick your vehicle",
    body: "Filter by type, fuel, transmission, seats and budget. Every listing shows real specifications and the current status of that car.",
  },
  {
    icon: CalendarCheck,
    title: "Check availability",
    body: "Availability is checked against live bookings, so a vehicle marked available for your dates is genuinely free.",
  },
  {
    icon: ClipboardCheck,
    title: "Verify your documents",
    body: "Upload your driving licence and one photo ID. Verification usually finishes within an hour and is reused for future rentals.",
  },
  {
    icon: BadgeCheck,
    title: "Review the quote",
    body: "You see the daily rate, number of days, insurance, taxes and any discount before anything is confirmed.",
  },
  {
    icon: CreditCard,
    title: "Confirm and pay the deposit",
    body: "Pay the rental amount and a refundable security deposit. The deposit is released within five working days of return.",
  },
  {
    icon: KeyRound,
    title: "Collect the vehicle",
    body: "Arrive at the branch, complete a two-minute joint inspection with photos, and drive away.",
  },
  {
    icon: RotateCcw,
    title: "Return and close",
    body: "Return to the agreed branch with the same fuel level. The final invoice reaches your inbox the same day.",
  },
];

const requirements = [
  {
    title: "Driving licence",
    body: "A valid Indian licence held for at least one year. International visitors need an International Driving Permit alongside their home licence.",
  },
  {
    title: "Photo identity",
    body: "Aadhaar, passport or voter ID. The name must match the licence exactly.",
  },
  {
    title: "Minimum age",
    body: "21 for economy, sedan, SUV, electric and van categories. 25 for luxury vehicles.",
  },
  {
    title: "Security deposit",
    body: "Between ₹3,000 and ₹15,000 depending on the category, fully refundable after inspection.",
  },
];

const faqs = [
  {
    q: "How is the rental price calculated?",
    a: "Number of days multiplied by the daily rate, plus insurance and assistance, plus 18% GST. Rentals of seven days or more receive a 10% discount on the base amount.",
  },
  {
    q: "Can I cancel a confirmed booking?",
    a: "Yes. Cancellations made more than 24 hours before pickup are refunded in full. Within 24 hours, one day's rental is retained.",
  },
  {
    q: "What if I return the vehicle late?",
    a: "A grace period of one hour applies. After that, each additional block of six hours is charged at a quarter of the daily rate.",
  },
  {
    q: "Is fuel included?",
    a: "No. Vehicles are handed over with a recorded fuel level and should be returned at the same level, otherwise the difference is billed at the pump rate.",
  },
  {
    q: "Who can drive the vehicle?",
    a: "Only the person named on the booking, plus any additional driver added at pickup with their own verified licence.",
  },
];

function HowItWorksPage() {
  return (
    <>
      <section className="border-b border-border bg-sidebar text-sidebar-foreground">
        <div className="container-page py-12 md:py-16">
          <p className="eyebrow text-sidebar-foreground/60">The process</p>
          <h1 className="mt-3 text-3xl font-extrabold md:text-5xl">How renting works</h1>
          <p className="mt-4 max-w-2xl text-sidebar-foreground/75">
            Eight steps from first search to final invoice. No paperwork queues, no
            surprise charges at the counter.
          </p>
        </div>
      </section>

      <section className="section-y">
        <div className="container-page grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <div key={step.title} className="surface-panel p-6">
              <div className="flex items-center gap-3">
                <span className="flex size-10 items-center justify-center rounded-xl bg-accent/15 text-accent-foreground">
                  <step.icon className="size-5" aria-hidden="true" />
                </span>
                <span className="text-sm font-bold text-muted-foreground">
                  Step {index + 1}
                </span>
              </div>
              <h2 className="mt-4 text-base font-semibold">{step.title}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{step.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-surface section-y">
        <div className="container-page grid gap-10 lg:grid-cols-2">
          <div>
            <p className="eyebrow">Before you book</p>
            <h2 className="mt-2 text-3xl font-bold">What you need</h2>
            <p className="mt-3 text-muted-foreground">
              Documents are uploaded once. After the first verified rental, later bookings
              skip straight to confirmation.
            </p>
            <Button asChild className="mt-6">
              <Link to="/vehicles">Browse vehicles</Link>
            </Button>
          </div>
          <ul className="space-y-4">
            {requirements.map((item) => (
              <li key={item.title} className="surface-panel p-5">
                <h3 className="text-base font-semibold">{item.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{item.body}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section-y">
        <div className="container-page max-w-3xl">
          <p className="eyebrow">Questions</p>
          <h2 className="mt-2 text-3xl font-bold">Frequently asked</h2>
          <Accordion type="single" collapsible className="mt-8">
            {faqs.map((faq) => (
              <AccordionItem key={faq.q} value={faq.q}>
                <AccordionTrigger className="text-left text-base font-semibold">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          <p className="mt-8 text-sm text-muted-foreground">
            Still unsure about something?{" "}
            <Link to="/contact" className="font-semibold text-foreground underline">
              Contact our team
            </Link>
            .
          </p>
        </div>
      </section>
    </>
  );
}
