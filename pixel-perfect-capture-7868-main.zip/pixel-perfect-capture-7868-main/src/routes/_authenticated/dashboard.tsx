import { useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CalendarClock,
  CalendarCheck,
  CarFront,
  IndianRupee,
  LogOut,
  MapPin,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EmptyState } from "@/components/site/EmptyState";
import { supabase } from "@/integrations/supabase/client";
import {
  bookingsQuery,
  formatPrice,
  myProfileQuery,
  vehicleImage,
  type Booking,
} from "@/lib/riderent";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "My bookings dashboard | RideRent" },
      {
        name: "description",
        content:
          "See your upcoming RideRent reservations, review past rentals and cancel a booking you no longer need.",
      },
      { property: "og:title", content: "My RideRent dashboard" },
      {
        property: "og:description",
        content: "Upcoming and past vehicle rentals in one place.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DashboardPage,
});

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function formatDate(value: string) {
  return new Date(`${value}T00:00:00`).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function DashboardPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const bookings = useQuery(bookingsQuery);
  const profile = useQuery(myProfileQuery);
  const [cancelling, setCancelling] = useState<string | null>(null);

  const today = todayIso();
  const rows = bookings.data ?? [];

  const { upcoming, past } = useMemo(() => {
    const active = rows.filter(
      (item) => item.status !== "cancelled" && item.end_date >= today,
    );
    const done = rows.filter(
      (item) => item.status === "cancelled" || item.end_date < today,
    );
    return {
      upcoming: active.sort((a, b) => a.start_date.localeCompare(b.start_date)),
      past: done.sort((a, b) => b.start_date.localeCompare(a.start_date)),
    };
  }, [rows, today]);

  const totalSpend = rows
    .filter((item) => item.status !== "cancelled")
    .reduce((sum, item) => sum + Number(item.total_amount), 0);

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  async function handleCancel(booking: Booking) {
    setCancelling(booking.id);
    const { error } = await supabase.rpc("cancel_booking", { _booking_id: booking.id });
    setCancelling(null);
    if (error) {
      toast.error("We couldn't cancel that booking", { description: error.message });
      return;
    }
    toast.success(`Booking ${booking.reference} cancelled`);
    await queryClient.invalidateQueries({ queryKey: ["bookings"] });
  }

  return (
    <section className="section-y">
      <div className="container-page">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="eyebrow">My account</p>
            <h1 className="mt-2 text-3xl font-extrabold md:text-4xl">
              {profile.data?.full_name ? `Hello, ${profile.data.full_name}` : "My bookings"}
            </h1>
            <p className="mt-2 text-muted-foreground">
              Track upcoming pickups, review completed rentals and manage your reservations.
            </p>
          </div>
          <div className="flex gap-2">
            <Button asChild>
              <Link to="/vehicles">Book a vehicle</Link>
            </Button>
            <Button variant="outline" onClick={handleSignOut}>
              <LogOut className="size-4" aria-hidden="true" />
              Sign out
            </Button>
          </div>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          <StatCard
            icon={CalendarClock}
            label="Upcoming rentals"
            value={`${upcoming.length}`}
          />
          <StatCard icon={CarFront} label="Total bookings" value={`${rows.length}`} />
          <StatCard
            icon={IndianRupee}
            label="Lifetime spend"
            value={formatPrice(totalSpend)}
          />
        </div>

        <Tabs defaultValue="upcoming" className="mt-10">
          <TabsList>
            <TabsTrigger value="upcoming">Upcoming ({upcoming.length})</TabsTrigger>
            <TabsTrigger value="past">Past & cancelled ({past.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="mt-6 space-y-4">
            {bookings.isLoading ? (
              <Skeleton className="h-40 rounded-2xl" />
            ) : upcoming.length ? (
              upcoming.map((booking) => (
                <BookingCard
                  key={booking.id}
                  booking={booking}
                  onCancel={handleCancel}
                  cancelling={cancelling === booking.id}
                />
              ))
            ) : (
              <EmptyState
                title="No upcoming rentals"
                description="Pick a vehicle and choose your dates — your confirmed reservation will show up here."
                action={
                  <Button asChild>
                    <Link to="/vehicles">Browse vehicles</Link>
                  </Button>
                }
              />
            )}
          </TabsContent>

          <TabsContent value="past" className="mt-6 space-y-4">
            {bookings.isLoading ? (
              <Skeleton className="h-40 rounded-2xl" />
            ) : past.length ? (
              past.map((booking) => <BookingCard key={booking.id} booking={booking} />)
            ) : (
              <EmptyState
                title="Nothing here yet"
                description="Completed and cancelled rentals will be listed here for your records."
              />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof CarFront;
  label: string;
  value: string;
}) {
  return (
    <div className="surface-panel p-5">
      <Icon className="size-5 text-accent" aria-hidden="true" />
      <p className="mt-3 text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="text-2xl font-extrabold">{value}</p>
    </div>
  );
}

function BookingCard({
  booking,
  onCancel,
  cancelling,
}: {
  booking: Booking;
  onCancel?: (booking: Booking) => void;
  cancelling?: boolean;
}) {
  const image = vehicleImage(booking.vehicles?.vehicle_categories?.slug);

  return (
    <article className="surface-panel grid gap-5 p-5 md:grid-cols-[180px_1fr_auto] md:items-center">
      <img
        src={image}
        alt={booking.vehicles?.name ?? "Rented vehicle"}
        loading="lazy"
        width={512}
        height={342}
        className="h-28 w-full rounded-xl object-cover"
      />

      <div>
        <div className="flex flex-wrap items-center gap-2">
          <h2 className="text-lg font-bold">{booking.vehicles?.name ?? "Vehicle"}</h2>
          <Badge variant={booking.status === "cancelled" ? "outline" : "secondary"}>
            {booking.status === "cancelled" ? "Cancelled" : "Confirmed"}
          </Badge>
          <span className="text-xs text-muted-foreground">Ref {booking.reference}</span>
        </div>
        <p className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <CalendarCheck className="size-4 text-accent" aria-hidden="true" />
            {formatDate(booking.start_date)} → {formatDate(booking.end_date)} ·{" "}
            {booking.days} day{booking.days > 1 ? "s" : ""}
          </span>
          {booking.pickup ? (
            <span className="flex items-center gap-1.5">
              <MapPin className="size-4 text-accent" aria-hidden="true" />
              {booking.pickup.city} — {booking.pickup.branch_name}
            </span>
          ) : null}
        </p>
        <Separator className="my-3" />
        <p className="text-sm text-muted-foreground">
          Driver {booking.driver_name || "—"} · {booking.driver_phone || "no phone on file"}
        </p>
      </div>

      <div className="text-right">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">Total paid</p>
        <p className="text-2xl font-extrabold">{formatPrice(Number(booking.total_amount))}</p>
        {onCancel && booking.status !== "cancelled" ? (
          <Button
            variant="outline"
            size="sm"
            className="mt-3"
            disabled={cancelling}
            onClick={() => onCancel(booking)}
          >
            <XCircle className="size-4" aria-hidden="true" />
            {cancelling ? "Cancelling…" : "Cancel booking"}
          </Button>
        ) : null}
        {booking.vehicles?.slug ? (
          <div className="mt-2">
            <Button asChild variant="ghost" size="sm">
              <Link to="/vehicles/$slug" params={{ slug: booking.vehicles.slug }}>
                View vehicle
              </Link>
            </Button>
          </div>
        ) : null}
      </div>
    </article>
  );
}
