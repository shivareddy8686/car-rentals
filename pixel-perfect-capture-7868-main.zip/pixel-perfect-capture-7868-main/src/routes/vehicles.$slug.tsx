import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft,
  BadgeCheck,
  Calendar,
  Check,
  DoorOpen,
  Fuel,
  Gauge,
  Heart,
  Loader2,
  MapPin,
  Settings2,
  Snowflake,
  Users,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RatingStars } from "@/components/site/RatingStars";
import { StatusBadge } from "@/components/site/StatusBadge";
import { EmptyState } from "@/components/site/EmptyState";
import { VehicleCard } from "@/components/site/VehicleCard";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import {
  bookedRangesQuery,
  formatPrice,
  locationsQuery,
  myProfileQuery,
  rangesOverlap,
  vehicleImage,
  vehicleQuery,
  vehiclesQuery,
} from "@/lib/riderent";

export const Route = createFileRoute("/vehicles/$slug")({
  head: ({ params }) => {
    const name = params.slug
      .split("-")
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join(" ");
    return {
      meta: [
        { title: `${name} Rental — Specs, Features & Daily Rate | RideRent` },
        {
          name: "description",
          content: `Rent the ${name} from RideRent. See seats, fuel, transmission, mileage, included features and the all-in daily rate before you book.`,
        },
        { property: "og:title", content: `${name} Rental — RideRent` },
        {
          property: "og:description",
          content: `Full specifications, features and transparent pricing for the ${name}.`,
        },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: VehicleDetailsPage,
});

function daysBetween(from: string, to: string) {
  if (!from || !to) return 0;
  const diff = new Date(to).getTime() - new Date(from).getTime();
  if (Number.isNaN(diff) || diff < 0) return 0;
  return Math.max(1, Math.round(diff / 86_400_000));
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function VehicleDetailsPage() {
  const { slug } = Route.useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAuthenticated, loading: authLoading } = useAuth();
  const vehicleResult = useQuery(vehicleQuery(slug));
  const locations = useQuery(locationsQuery);
  const fleet = useQuery(vehiclesQuery);

  const vehicle = vehicleResult.data;
  const bookedRanges = useQuery(bookedRangesQuery(vehicle?.id));
  const profile = useQuery({ ...myProfileQuery, enabled: isAuthenticated });

  const [pickup, setPickup] = useState("");
  const [dropoff, setDropoff] = useState("");
  const [pickupDate, setPickupDate] = useState(today());
  const [returnDate, setReturnDate] = useState("");
  const [driverName, setDriverName] = useState("");
  const [driverPhone, setDriverPhone] = useState("");
  const [saved, setSaved] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (profile.data) {
      setDriverName((value) => value || profile.data!.full_name);
      setDriverPhone((value) => value || profile.data!.phone);
    }
  }, [profile.data]);

  const days = daysBetween(pickupDate, returnDate);
  const base = (vehicle?.price_per_day ?? 0) * days;
  const insurance = days * 299;
  const discount = days >= 7 ? Math.round(base * 0.1) : 0;
  const taxes = Math.round((base + insurance - discount) * 0.18);
  const total = base + insurance - discount + taxes;

  const ranges = bookedRanges.data ?? [];
  const datesClash =
    Boolean(pickupDate && returnDate) && rangesOverlap(ranges, pickupDate, returnDate);

  const similar = useMemo(
    () =>
      (fleet.data ?? [])
        .filter(
          (item) =>
            item.slug !== slug &&
            item.category_id === vehicle?.category_id,
        )
        .slice(0, 3),
    [fleet.data, slug, vehicle?.category_id],
  );

  if (vehicleResult.isLoading) {
    return (
      <div className="container-page section-y grid gap-8 lg:grid-cols-[1.5fr_1fr]">
        <Skeleton className="h-[420px] rounded-2xl" />
        <Skeleton className="h-[420px] rounded-2xl" />
      </div>
    );
  }

  if (!vehicle) {
    return (
      <div className="container-page section-y">
        <EmptyState
          title="Vehicle not found"
          description="This vehicle may have been retired from the fleet. Browse the full catalogue instead."
          action={
            <Button asChild>
              <Link to="/vehicles">Browse vehicles</Link>
            </Button>
          }
        />
      </div>
    );
  }

  const image = vehicleImage(vehicle.vehicle_categories?.slug);

  const specs = [
    { icon: Users, label: "Seats", value: `${vehicle.seats}` },
    { icon: DoorOpen, label: "Doors", value: `${vehicle.doors}` },
    { icon: Fuel, label: "Fuel type", value: vehicle.fuel_type },
    { icon: Settings2, label: "Transmission", value: vehicle.transmission },
    { icon: Gauge, label: "Mileage", value: vehicle.mileage },
    { icon: Calendar, label: "Year", value: `${vehicle.manufacturing_year}` },
    {
      icon: Snowflake,
      label: "Air conditioning",
      value: vehicle.has_air_conditioning ? "Yes" : "No",
    },
    { icon: MapPin, label: "GPS", value: vehicle.has_gps ? "Built-in" : "Not fitted" },
  ];

  async function handleBooking(event: React.FormEvent) {
    event.preventDefault();
    if (!pickup || !dropoff) {
      setError("Choose both a pickup and a return branch.");
      return;
    }
    if (!returnDate) {
      setError("Choose a return date.");
      return;
    }
    if (returnDate < pickupDate) {
      setError("The return date must be on or after the pickup date.");
      return;
    }
    if (pickupDate < today()) {
      setError("The pickup date cannot be in the past.");
      return;
    }
    if (vehicle?.status !== "available") {
      setError("This vehicle is not available for the moment. Try a similar one below.");
      return;
    }
    if (driverName.trim().length < 3) {
      setError("Enter the main driver's full name.");
      return;
    }
    if (!/^[0-9+\s-]{10,15}$/.test(driverPhone.trim())) {
      setError("Enter a phone number we can reach the driver on.");
      return;
    }
    if (!isAuthenticated) {
      setError(null);
      toast.info("Sign in to confirm your reservation");
      navigate({ to: "/auth", search: { redirect: window.location.pathname } });
      return;
    }
    if (datesClash) {
      setError("Those dates are already booked. Pick different dates or a similar vehicle.");
      return;
    }

    setError(null);
    setSubmitting(true);

    const { data: freeCheck, error: checkError } = await supabase.rpc("is_vehicle_available", {
      _vehicle_id: vehicle.id,
      _start: pickupDate,
      _end: returnDate,
    });

    if (checkError) {
      setSubmitting(false);
      setError("We couldn't check availability just now. Please try again.");
      return;
    }
    if (!freeCheck) {
      setSubmitting(false);
      setError("This vehicle was just booked for those dates. Try other dates.");
      await queryClient.invalidateQueries({ queryKey: ["booked_ranges", vehicle.id] });
      return;
    }

    const { data, error: bookingError } = await supabase.rpc("create_booking", {
      _vehicle_id: vehicle.id,
      _pickup_location_id: pickup,
      _return_location_id: dropoff,
      _start: pickupDate,
      _end: returnDate,
      _driver_name: driverName.trim(),
      _driver_phone: driverPhone.trim(),
      _notes: "",
    });

    setSubmitting(false);

    if (bookingError) {
      setError(bookingError.message);
      return;
    }

    const reference = (data as { reference?: string } | null)?.reference;
    toast.success("Booking confirmed", {
      description: reference
        ? `Reference ${reference} · ${formatPrice(total)} total`
        : `${days} day${days > 1 ? "s" : ""} · ${formatPrice(total)} total`,
    });
    await queryClient.invalidateQueries({ queryKey: ["bookings"] });
    await queryClient.invalidateQueries({ queryKey: ["booked_ranges", vehicle.id] });
    navigate({ to: "/dashboard" });
  }

  return (
    <>
      <div className="border-b border-border bg-surface">
        <div className="container-page flex flex-wrap items-center gap-2 py-4 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-foreground">
            Home
          </Link>
          <span aria-hidden="true">/</span>
          <Link to="/vehicles" className="hover:text-foreground">
            Vehicles
          </Link>
          <span aria-hidden="true">/</span>
          <span className="font-medium text-foreground">{vehicle.name}</span>
        </div>
      </div>

      <section className="section-y">
        <div className="container-page grid gap-10 lg:grid-cols-[1.55fr_1fr] lg:items-start">
          <div className="space-y-8">
            <div className="surface-panel overflow-hidden">
              <img
                src={image}
                alt={`${vehicle.brand} ${vehicle.model} rental vehicle`}
                width={1024}
                height={683}
                className="h-[320px] w-full object-cover md:h-[420px]"
              />
              <div className="grid grid-cols-3 gap-3 p-3">
                {[0, 1, 2].map((index) => (
                  <img
                    key={index}
                    src={image}
                    alt={`${vehicle.name} view ${index + 2}`}
                    loading="lazy"
                    width={512}
                    height={342}
                    className="h-24 w-full rounded-xl object-cover"
                  />
                ))}
              </div>
            </div>

            <div>
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="eyebrow">{vehicle.brand}</p>
                  <h1 className="mt-2 text-3xl font-extrabold md:text-4xl">
                    {vehicle.name}
                  </h1>
                  <p className="mt-2 text-muted-foreground">
                    {vehicle.model} · {vehicle.vehicle_categories?.name} ·{" "}
                    {vehicle.registration_number}
                  </p>
                </div>
                <div className="flex flex-col items-start gap-2">
                  <StatusBadge status={vehicle.status} />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSaved((value) => !value);
                      toast.success(saved ? "Removed from saved" : "Saved for later");
                    }}
                    aria-pressed={saved}
                  >
                    <Heart
                      className={saved ? "size-4 fill-destructive text-destructive" : "size-4"}
                      aria-hidden="true"
                    />
                    {saved ? "Saved" : "Save"}
                  </Button>
                </div>
              </div>

              <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                <RatingStars rating={vehicle.rating} size={16} />
                <span className="font-semibold text-foreground">
                  {vehicle.rating.toFixed(1)}
                </span>
                <span>({vehicle.review_count} reviews)</span>
                <span aria-hidden="true">·</span>
                <span>{vehicle.booking_count} completed rentals</span>
              </div>

              <p className="mt-6 leading-relaxed text-muted-foreground">
                {vehicle.description}
              </p>
            </div>

            <div>
              <h2 className="text-xl font-bold">Specifications</h2>
              <dl className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {specs.map((spec) => (
                  <div key={spec.label} className="surface-panel p-4">
                    <spec.icon className="size-4 text-accent" aria-hidden="true" />
                    <dt className="mt-2 text-xs uppercase tracking-wide text-muted-foreground">
                      {spec.label}
                    </dt>
                    <dd className="text-sm font-semibold">{spec.value}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div>
              <h2 className="text-xl font-bold">Features included</h2>
              <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                {(vehicle.features ?? []).map((feature) => (
                  <li
                    key={feature}
                    className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-3 text-sm"
                  >
                    <Check className="size-4 text-success" aria-hidden="true" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {vehicle.locations ? (
              <div className="surface-panel p-6">
                <h2 className="text-xl font-bold">Pickup branch</h2>
                <p className="mt-2 flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="size-4 text-accent" aria-hidden="true" />
                  {vehicle.locations.branch_name}, {vehicle.locations.city}
                </p>
                <Button asChild variant="outline" size="sm" className="mt-4">
                  <Link to="/locations">See all branches</Link>
                </Button>
              </div>
            ) : null}
          </div>

          <form
            onSubmit={handleBooking}
            aria-label="Booking summary"
            className="surface-panel space-y-4 p-6 lg:sticky lg:top-24"
          >
            <div>
              <p className="text-3xl font-extrabold">
                {formatPrice(vehicle.price_per_day)}
                <span className="text-sm font-medium text-muted-foreground"> / day</span>
              </p>
              <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
                <BadgeCheck className="size-3.5 text-success" aria-hidden="true" />
                250 km per day included · no hidden charges
              </p>
            </div>

            <Separator />

            <div className="space-y-1.5">
              <Label htmlFor="book-pickup">Pickup location</Label>
              <Select value={pickup} onValueChange={setPickup}>
                <SelectTrigger id="book-pickup">
                  <SelectValue placeholder="Select a branch" />
                </SelectTrigger>
                <SelectContent>
                  {(locations.data ?? []).map((location) => (
                    <SelectItem key={location.id} value={location.id}>
                      {location.city} — {location.branch_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="book-dropoff">Return location</Label>
              <Select value={dropoff} onValueChange={setDropoff}>
                <SelectTrigger id="book-dropoff">
                  <SelectValue placeholder="Select a branch" />
                </SelectTrigger>
                <SelectContent>
                  {(locations.data ?? []).map((location) => (
                    <SelectItem key={location.id} value={location.id}>
                      {location.city} — {location.branch_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="book-pickup-date">Pickup date</Label>
                <Input
                  id="book-pickup-date"
                  type="date"
                  min={today()}
                  value={pickupDate}
                  onChange={(event) => setPickupDate(event.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="book-return-date">Return date</Label>
                <Input
                  id="book-return-date"
                  type="date"
                  min={pickupDate || today()}
                  value={returnDate}
                  onChange={(event) => setReturnDate(event.target.value)}
                />
              </div>
            </div>

            {datesClash ? (
              <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-xs text-destructive">
                Already reserved for those dates. Please choose another window.
              </p>
            ) : pickupDate && returnDate ? (
              <p className="flex items-center gap-1.5 rounded-lg bg-success/10 px-3 py-2 text-xs text-success">
                <BadgeCheck className="size-3.5" aria-hidden="true" />
                Free for {pickupDate} to {returnDate}
              </p>
            ) : null}

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="book-driver">Main driver</Label>
                <Input
                  id="book-driver"
                  autoComplete="name"
                  placeholder="Name on licence"
                  value={driverName}
                  onChange={(event) => setDriverName(event.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="book-phone">Phone</Label>
                <Input
                  id="book-phone"
                  type="tel"
                  autoComplete="tel"
                  placeholder="10-digit mobile"
                  value={driverPhone}
                  onChange={(event) => setDriverPhone(event.target.value)}
                />
              </div>
            </div>

            <Separator />

            <dl className="space-y-2 text-sm">
              <Row label="Rental days" value={days ? `${days}` : "—"} />
              <Row label="Price per day" value={formatPrice(vehicle.price_per_day)} />
              <Row label="Base rental cost" value={formatPrice(base)} />
              <Row label="Insurance & assistance" value={formatPrice(insurance)} />
              <Row
                label="Long-rental discount"
                value={discount ? `- ${formatPrice(discount)}` : formatPrice(0)}
              />
              <Row label="Taxes (18% GST)" value={formatPrice(taxes)} />
            </dl>

            <Separator />

            <div className="flex items-baseline justify-between">
              <span className="text-sm font-semibold">Total payable</span>
              <span className="text-2xl font-extrabold">{formatPrice(total)}</span>
            </div>

            {error ? (
              <p role="alert" className="text-sm text-destructive">
                {error}
              </p>
            ) : null}

            <Button
              type="submit"
              size="lg"
              className="w-full"
              disabled={submitting || authLoading || datesClash}
            >
              {submitting ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : null}
              {isAuthenticated ? "Confirm booking" : "Sign in to book"}
            </Button>
            <p className="text-center text-xs text-muted-foreground">
              A refundable security deposit applies at pickup.
            </p>
          </form>
        </div>
      </section>

      {similar.length ? (
        <section className="bg-surface section-y">
          <div className="container-page">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <h2 className="text-2xl font-bold md:text-3xl">Similar vehicles</h2>
              <Button asChild variant="outline">
                <Link to="/vehicles">
                  <ArrowLeft className="size-4" aria-hidden="true" />
                  Back to all vehicles
                </Link>
              </Button>
            </div>
            <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {similar.map((item) => (
                <VehicleCard key={item.id} vehicle={item} />
              ))}
            </div>
          </div>
        </section>
      ) : null}
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="font-medium">{value}</dd>
    </div>
  );
}
