import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Clock, Mail, MapPin, Phone } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { locationsQuery, vehiclesQuery } from "@/lib/riderent";

export const Route = createFileRoute("/locations")({
  head: () => ({
    meta: [
      { title: "RideRent Branches — Pickup Locations & Opening Hours" },
      {
        name: "description",
        content:
          "Find RideRent pickup and return branches with addresses, phone numbers, email and opening hours. One-way rentals between any two branches.",
      },
      { property: "og:title", content: "RideRent Branches & Pickup Locations" },
      {
        property: "og:description",
        content: "Addresses, contact details and opening hours for every RideRent branch.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LocationsPage,
});

function LocationsPage() {
  const locations = useQuery(locationsQuery);
  const vehicles = useQuery(vehiclesQuery);

  function countFor(slug: string) {
    return (vehicles.data ?? []).filter((v) => v.locations?.slug === slug).length;
  }

  return (
    <>
      <section className="border-b border-border bg-sidebar text-sidebar-foreground">
        <div className="container-page py-12 md:py-16">
          <p className="eyebrow text-sidebar-foreground/60">Where to find us</p>
          <h1 className="mt-3 text-3xl font-extrabold md:text-5xl">Our branches</h1>
          <p className="mt-4 max-w-2xl text-sidebar-foreground/75">
            Every branch is staffed seven days a week, handles document verification on the
            spot and supports one-way rentals to any other RideRent city.
          </p>
        </div>
      </section>

      <section className="section-y">
        <div className="container-page">
          {locations.isLoading ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, index) => (
                <Skeleton key={index} className="h-64 rounded-2xl" />
              ))}
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {(locations.data ?? []).map((location) => (
                <article key={location.id} className="surface-panel flex flex-col p-6">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h2 className="text-lg font-semibold">{location.city}</h2>
                      <p className="text-sm text-muted-foreground">
                        {location.branch_name}
                      </p>
                    </div>
                    <span className="rounded-full bg-accent/15 px-2.5 py-1 text-xs font-semibold text-accent-foreground">
                      {countFor(location.slug)} vehicles
                    </span>
                  </div>

                  <ul className="mt-5 space-y-3 text-sm text-muted-foreground">
                    <li className="flex gap-2">
                      <MapPin className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                      {location.address}
                    </li>
                    <li className="flex gap-2">
                      <Clock className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                      {location.opening_hours}
                    </li>
                    <li className="flex gap-2">
                      <Phone className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                      <a href={`tel:${location.contact_phone}`} className="hover:text-foreground">
                        {location.contact_phone}
                      </a>
                    </li>
                    <li className="flex gap-2">
                      <Mail className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                      <a
                        href={`mailto:${location.contact_email}`}
                        className="hover:text-foreground"
                      >
                        {location.contact_email}
                      </a>
                    </li>
                  </ul>

                  <Button asChild variant="outline" size="sm" className="mt-6 self-start">
                    <Link to="/vehicles" search={{ location: location.slug }}>
                      View vehicles here
                    </Link>
                  </Button>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
