import { createFileRoute, Link } from "@tanstack/react-router";
import { Building2, Leaf, ShieldCheck, Target, Users2, Wrench } from "lucide-react";

import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About RideRent — Our Fleet Standards and Story" },
      {
        name: "description",
        content:
          "RideRent started in 2019 with six cars in Pune. Learn how we maintain the fleet, price rentals transparently and support customers around the clock.",
      },
      { property: "og:title", content: "About RideRent" },
      {
        property: "og:description",
        content:
          "Our story, our fleet standards and the principles behind transparent vehicle rental.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

const values = [
  {
    icon: Target,
    title: "Transparent pricing",
    body: "The quote you see before booking is the amount you pay. Kilometre limits, deposits and taxes are all stated up front.",
  },
  {
    icon: Wrench,
    title: "Serviced every 5,000 km",
    body: "Each vehicle goes through a 42-point inspection between rentals, logged against its registration number.",
  },
  {
    icon: ShieldCheck,
    title: "Insured on every trip",
    body: "Comprehensive insurance and roadside assistance are included in the daily rate, not sold as an upsell.",
  },
  {
    icon: Leaf,
    title: "A growing electric fleet",
    body: "One in five vehicles is now electric, and every branch has charging support and route guidance.",
  },
];

const milestones = [
  { year: "2019", body: "RideRent opens in Pune with six cars and a single-page booking form." },
  { year: "2021", body: "Bengaluru and Hyderabad branches launch; the fleet crosses 120 vehicles." },
  { year: "2023", body: "One-way intercity rentals introduced along with same-day licence verification." },
  { year: "2026", body: "500+ vehicles, 25 branches and over 10,000 completed rentals." },
];

const team = [
  { name: "Meera Raghavan", role: "Founder & CEO" },
  { name: "Arjun Nair", role: "Head of Fleet Operations" },
  { name: "Sana Kapoor", role: "Customer Experience Lead" },
  { name: "Vikram Desai", role: "Head of Engineering" },
];

function AboutPage() {
  return (
    <>
      <section className="border-b border-border bg-sidebar text-sidebar-foreground">
        <div className="container-page py-12 md:py-16">
          <p className="eyebrow text-sidebar-foreground/60">About us</p>
          <h1 className="mt-3 text-3xl font-extrabold md:text-5xl">
            Vehicle rental without the fine print
          </h1>
          <p className="mt-4 max-w-2xl text-sidebar-foreground/75">
            We started RideRent because renting a car in India meant guessing the final
            bill. Seven years later, every rate, limit and charge is visible before you
            book.
          </p>
        </div>
      </section>

      <section className="section-y">
        <div className="container-page grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {values.map((value) => (
            <div key={value.title} className="surface-panel p-6">
              <span className="flex size-11 items-center justify-center rounded-xl bg-accent/15 text-accent-foreground">
                <value.icon className="size-5" aria-hidden="true" />
              </span>
              <h2 className="mt-4 text-base font-semibold">{value.title}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{value.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-surface section-y">
        <div className="container-page grid gap-10 lg:grid-cols-2">
          <div>
            <p className="eyebrow">Our story</p>
            <h2 className="mt-2 text-3xl font-bold">From six cars to twenty-five cities</h2>
            <p className="mt-4 text-muted-foreground">
              RideRent grew out of a small garage in Kothrud, Pune, where the founding team
              rented out their own cars to colleagues who needed weekend transport. The
              rules were simple: a clean car, a clear price and a phone number that always
              answers. Those rules still run the business.
            </p>
            <p className="mt-4 text-muted-foreground">
              Today the fleet spans economy hatchbacks to luxury sedans, but every vehicle
              is still handed over in person, inspected jointly and photographed before the
              keys change hands.
            </p>
            <Button asChild className="mt-6">
              <Link to="/vehicles">See the fleet</Link>
            </Button>
          </div>
          <ol className="space-y-4">
            {milestones.map((item) => (
              <li key={item.year} className="surface-panel flex gap-4 p-5">
                <span className="text-lg font-extrabold text-accent-foreground">
                  {item.year}
                </span>
                <p className="text-sm text-muted-foreground">{item.body}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="section-y">
        <div className="container-page">
          <p className="eyebrow">The team</p>
          <h2 className="mt-2 text-3xl font-bold">People behind the keys</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {team.map((member) => (
              <div key={member.name} className="surface-panel p-6 text-center">
                <span className="mx-auto flex size-14 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
                  <Users2 className="size-6" aria-hidden="true" />
                </span>
                <h3 className="mt-4 text-base font-semibold">{member.name}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{member.role}</p>
              </div>
            ))}
          </div>

          <div className="surface-panel mt-12 flex flex-wrap items-center justify-between gap-4 p-8">
            <div className="flex items-start gap-3">
              <Building2 className="mt-1 size-5 text-accent" aria-hidden="true" />
              <div>
                <h2 className="text-lg font-semibold">Renting for your company?</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Corporate accounts get monthly invoicing, priority allocation and a named
                  account manager.
                </p>
              </div>
            </div>
            <Button asChild variant="outline">
              <Link to="/contact">Talk to us</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
