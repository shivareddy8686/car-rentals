import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  BadgeCheck,
  CalendarCheck,
  CarFront,
  Headset,
  KeyRound,
  MapPin,
  Quote,
  ShieldCheck,
  Sparkles,
  Wallet,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Skeleton } from "@/components/ui/skeleton";
import { VehicleCard } from "@/components/site/VehicleCard";
import { SearchWidget } from "@/components/site/SearchWidget";
import { categoriesQuery, locationsQuery, vehiclesQuery, vehicleImage } from "@/lib/riderent";
import heroImage from "@/assets/hero-riderent.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "RideRent — Car & SUV Rentals at Transparent Daily Rates" },
      {
        name: "description",
        content:
          "Find the perfect ride for every journey. Browse economy cars, SUVs, electric and luxury vehicles across 5 cities with clear daily pricing.",
      },
      {
        property: "og:title",
        content: "RideRent — Car & SUV Rentals at Transparent Daily Rates",
      },
      {
        property: "og:description",
        content:
          "Reliable cars, SUVs and premium vehicles with transparent daily rates and 24/7 support.",
      },
    ],
  }),
  component: HomePage,
});

const stats = [
  { value: "500+", label: "Vehicles in the fleet" },
  { value: "10,000+", label: "Happy customers" },
  { value: "25+", label: "Pickup locations" },
  { value: "24/7", label: "Roadside support" },
];

const whyChoose = [
  {
    icon: Wallet,
    title: "Transparent daily pricing",
    body: "The rate you see is the rate you pay. Taxes and insurance are itemised before you confirm.",
  },
  {
    icon: ShieldCheck,
    title: "Insured, inspected fleet",
    body: "Every vehicle passes a 42-point inspection between rentals and carries comprehensive cover.",
  },
  {
    icon: CalendarCheck,
    title: "Free changes up to 24h",
    body: "Plans shift. Modify or cancel any booking up to 24 hours before pickup at no cost.",
  },
  {
    icon: Headset,
    title: "Real humans on call",
    body: "Our support desk answers in under two minutes, day or night, in English and Hindi.",
  },
];

const steps = [
  {
    icon: MapPin,
    title: "Pick your city and dates",
    body: "Choose a pickup branch, return branch and the days you need the vehicle.",
  },
  {
    icon: CarFront,
    title: "Choose your vehicle",
    body: "Filter by type, fuel, transmission and budget, then compare real specifications.",
  },
  {
    icon: BadgeCheck,
    title: "Verify your licence",
    body: "Upload your driving licence and ID once — future bookings skip this step.",
  },
  {
    icon: KeyRound,
    title: "Collect and drive",
    body: "Show up at the branch, complete a two-minute handover and start your journey.",
  },
];

const testimonials = [
  {
    quote:
      "Booked a Fortuner for a Coorg trip. The handover took four minutes and the car was spotless. The itemised bill matched the quote exactly.",
    name: "Ananya Iyer",
    role: "Product designer, Bengaluru",
  },
  {
    quote:
      "I rent a Camry from the Hyderabad branch twice a month for client visits. Same car, same condition, invoice in my inbox every time.",
    name: "Rohit Verma",
    role: "Regional sales lead, Hyderabad",
  },
  {
    quote:
      "The Nexon EV cost me less than a week of cabs. Charging guidance from the support desk was genuinely useful.",
    name: "Fatima Sheikh",
    role: "Doctoral researcher, Pune",
  },
];

const faqs = [
  {
    q: "What documents do I need to rent a vehicle?",
    a: "A valid Indian driving licence held for at least one year, plus one government photo ID (Aadhaar, passport or voter ID). Both are uploaded once and reused for later bookings.",
  },
  {
    q: "Is there a security deposit?",
    a: "Yes. A refundable deposit between ₹3,000 and ₹15,000 applies depending on the vehicle category. It is released within five working days of return.",
  },
  {
    q: "Are there kilometre limits?",
    a: "Each rental day includes 250 km. Additional kilometres are billed at ₹9 to ₹22 per km depending on the category, and the rate is shown before you confirm.",
  },
  {
    q: "Can I return the vehicle in a different city?",
    a: "One-way rentals between any two RideRent branches are supported. A relocation fee is calculated from the distance and shown in the booking summary.",
  },
  {
    q: "What happens if the vehicle breaks down?",
    a: "Call the 24/7 support line. Roadside assistance is included on every rental and a replacement vehicle is arranged where a repair would take over two hours.",
  },
];

export default function HomePage() {
  const vehicles = useQuery(vehiclesQuery);
  const categories = useQuery(categoriesQuery);
  const locations = useQuery(locationsQuery);

  const popular = (vehicles.data ?? []).filter((v) => v.is_featured).slice(0, 6);

  return (
    <>
      <section className="relative isolate overflow-hidden">
        <img
          src={heroImage}
          alt="Silver SUV on a coastal highway at sunset"
          width={1920}
          height={1088}
          className="absolute inset-0 size-full object-cover"
        />
        <div className="hero-overlay absolute inset-0" aria-hidden="true" />
        <div className="container-page relative py-20 md:py-28">
          <div className="max-w-2xl text-primary-foreground">
            <p className="eyebrow text-primary-foreground/70">
              Rent the ride. Own the journey.
            </p>
            <h1 className="mt-4 text-4xl font-extrabold leading-[1.05] md:text-6xl">
              Find the perfect ride for every journey.
            </h1>
            <p className="mt-5 max-w-xl text-base text-primary-foreground/80 md:text-lg">
              Choose from reliable cars, SUVs and premium vehicles at transparent daily
              rates.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to="/vehicles">Browse vehicles</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-primary-foreground/40 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
              >
                <Link to="/how-it-works">Start renting</Link>
              </Button>
            </div>
          </div>

          <div className="mt-12">
            <SearchWidget
              categories={categories.data ?? []}
              locations={locations.data ?? []}
            />
          </div>
        </div>
      </section>

      <section className="border-b border-border bg-card">
        <div className="container-page grid grid-cols-2 gap-6 py-10 md:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label}>
              <p className="text-3xl font-extrabold md:text-4xl">{stat.value}</p>
              <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section-y">
        <div className="container-page">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow">Most requested</p>
              <h2 className="mt-2 text-3xl font-bold md:text-4xl">Popular vehicles</h2>
              <p className="mt-2 max-w-xl text-muted-foreground">
                The cars our customers come back to, ranked by rating and completed
                rentals.
              </p>
            </div>
            <Button asChild variant="outline">
              <Link to="/vehicles">View all vehicles</Link>
            </Button>
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {vehicles.isLoading
              ? Array.from({ length: 6 }).map((_, index) => (
                  <Skeleton key={index} className="h-96 rounded-2xl" />
                ))
              : popular.map((vehicle) => (
                  <VehicleCard key={vehicle.id} vehicle={vehicle} />
                ))}
          </div>
          {vehicles.isError ? (
            <p className="mt-6 text-sm text-destructive">
              Something went wrong loading the fleet. Please refresh the page.
            </p>
          ) : null}
        </div>
      </section>

      <section className="bg-surface section-y">
        <div className="container-page">
          <p className="eyebrow">Browse by type</p>
          <h2 className="mt-2 text-3xl font-bold md:text-4xl">Vehicle categories</h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {(categories.data ?? []).map((category) => (
              <Link
                key={category.id}
                to="/vehicles"
                search={{ category: category.slug }}
                className="surface-panel group overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-lift)]"
              >
                <img
                  src={vehicleImage(category.slug)}
                  alt={`${category.name} rental vehicle`}
                  loading="lazy"
                  width={1024}
                  height={683}
                  className="h-40 w-full object-cover transition-transform duration-500 group-hover:scale-[1.05]"
                />
                <div className="space-y-1.5 p-5">
                  <h3 className="text-lg font-semibold">{category.name}</h3>
                  <p className="text-sm text-muted-foreground">{category.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="section-y">
        <div className="container-page">
          <p className="eyebrow">Why RideRent</p>
          <h2 className="mt-2 text-3xl font-bold md:text-4xl">
            Rentals without the fine print
          </h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {whyChoose.map((item) => (
              <div key={item.title} className="surface-panel p-6">
                <span className="flex size-11 items-center justify-center rounded-xl bg-accent/15 text-accent-foreground">
                  <item.icon className="size-5" aria-hidden="true" />
                </span>
                <h3 className="mt-4 text-base font-semibold">{item.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{item.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-sidebar text-sidebar-foreground section-y">
        <div className="container-page">
          <p className="eyebrow text-sidebar-foreground/60">Four steps</p>
          <h2 className="mt-2 text-3xl font-bold md:text-4xl">How it works</h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {steps.map((step, index) => (
              <div
                key={step.title}
                className="rounded-2xl border border-sidebar-border bg-sidebar-accent p-6"
              >
                <div className="flex items-center justify-between">
                  <span className="flex size-11 items-center justify-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground">
                    <step.icon className="size-5" aria-hidden="true" />
                  </span>
                  <span className="text-2xl font-extrabold text-sidebar-foreground/25">
                    0{index + 1}
                  </span>
                </div>
                <h3 className="mt-4 text-base font-semibold">{step.title}</h3>
                <p className="mt-2 text-sm text-sidebar-foreground/70">{step.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-y">
        <div className="container-page">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow">Where to find us</p>
              <h2 className="mt-2 text-3xl font-bold md:text-4xl">Featured locations</h2>
            </div>
            <Button asChild variant="outline">
              <Link to="/locations">All locations</Link>
            </Button>
          </div>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {(locations.data ?? []).slice(0, 3).map((location) => (
              <div key={location.id} className="surface-panel p-6">
                <p className="eyebrow">{location.city}</p>
                <h3 className="mt-2 text-lg font-semibold">{location.branch_name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{location.address}</p>
                <p className="mt-4 text-sm font-medium">Open {location.opening_hours}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-surface section-y">
        <div className="container-page">
          <p className="eyebrow">Customer stories</p>
          <h2 className="mt-2 text-3xl font-bold md:text-4xl">
            What renters tell us
          </h2>
          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {testimonials.map((item) => (
              <blockquote key={item.name} className="surface-panel p-6">
                <Quote className="size-6 text-accent" aria-hidden="true" />
                <p className="mt-4 text-sm leading-relaxed">{item.quote}</p>
                <footer className="mt-5">
                  <p className="text-sm font-semibold">{item.name}</p>
                  <p className="text-xs text-muted-foreground">{item.role}</p>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className="section-y">
        <div className="container-page grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="eyebrow">Good to know</p>
            <h2 className="mt-2 text-3xl font-bold md:text-4xl">
              Frequently asked questions
            </h2>
            <p className="mt-3 text-muted-foreground">
              Still unsure about something? Our support desk answers in under two minutes.
            </p>
            <Button asChild className="mt-6">
              <Link to="/contact">Contact support</Link>
            </Button>
          </div>
          <Accordion type="single" collapsible className="surface-panel px-5">
            {faqs.map((faq) => (
              <AccordionItem key={faq.q} value={faq.q}>
                <AccordionTrigger className="text-left text-base font-semibold">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      <section className="pb-20">
        <div className="container-page">
          <div className="relative overflow-hidden rounded-3xl bg-primary px-8 py-14 text-primary-foreground shadow-[var(--shadow-panel)]">
            <Sparkles
              className="absolute -right-6 -top-6 size-40 text-primary-foreground/10"
              aria-hidden="true"
            />
            <div className="relative max-w-2xl">
              <h2 className="text-3xl font-bold md:text-4xl">
                Your next journey is one booking away.
              </h2>
              <p className="mt-3 text-primary-foreground/80">
                Compare 22 live vehicles across 5 cities, with clear daily rates and no
                hidden charges at the counter.
              </p>
              <div className="mt-7 flex flex-wrap gap-3">
                <Button asChild size="lg" variant="secondary">
                  <Link to="/vehicles">Browse the fleet</Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-primary-foreground/40 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
                >
                  <Link to="/locations">Find a branch</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
