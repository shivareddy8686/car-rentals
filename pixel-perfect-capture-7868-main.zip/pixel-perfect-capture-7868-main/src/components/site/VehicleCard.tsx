import { Link } from "@tanstack/react-router";
import { Fuel, Gauge, MapPin, Users } from "lucide-react";

import { Button } from "@/components/ui/button";
import { RatingStars } from "@/components/site/RatingStars";
import { StatusBadge } from "@/components/site/StatusBadge";
import { cn } from "@/lib/utils";
import { formatPrice, vehicleImage, type Vehicle } from "@/lib/riderent";

export function VehicleCard({
  vehicle,
  layout = "grid",
}: {
  vehicle: Vehicle;
  layout?: "grid" | "list";
}) {
  const image = vehicleImage(vehicle.vehicle_categories?.slug);

  return (
    <article
      className={cn(
        "group surface-panel overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-lift)]",
        layout === "list" && "sm:flex",
      )}
    >
      <div
        className={cn(
          "relative overflow-hidden bg-surface",
          layout === "list" ? "sm:w-72 sm:shrink-0" : "",
        )}
      >
        <img
          src={image}
          alt={`${vehicle.brand} ${vehicle.model} available for rent`}
          loading="lazy"
          width={1024}
          height={683}
          className="h-48 w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
        />
        <span className="absolute left-3 top-3 rounded-full bg-card/90 px-2.5 py-1 text-xs font-semibold text-foreground backdrop-blur">
          {vehicle.vehicle_categories?.name}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-4 p-5">
        <div className="space-y-1.5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                {vehicle.brand}
              </p>
              <h3 className="text-lg font-semibold leading-tight">{vehicle.name}</h3>
            </div>
            <StatusBadge status={vehicle.status} />
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <RatingStars rating={vehicle.rating} />
            <span className="font-medium text-foreground">{vehicle.rating.toFixed(1)}</span>
            <span>({vehicle.review_count} reviews)</span>
          </div>
        </div>

        <ul className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
          <li className="flex items-center gap-2">
            <Users className="size-4 text-accent" aria-hidden="true" />
            {vehicle.seats} seats
          </li>
          <li className="flex items-center gap-2">
            <Fuel className="size-4 text-accent" aria-hidden="true" />
            {vehicle.fuel_type}
          </li>
          <li className="flex items-center gap-2">
            <Gauge className="size-4 text-accent" aria-hidden="true" />
            {vehicle.transmission}
          </li>
          <li className="flex items-center gap-2">
            <MapPin className="size-4 text-accent" aria-hidden="true" />
            {vehicle.locations?.city ?? "Multiple cities"}
          </li>
        </ul>

        <div className="mt-auto flex flex-wrap items-end justify-between gap-3 border-t border-border pt-4">
          <p className="text-xl font-bold">
            {formatPrice(vehicle.price_per_day)}
            <span className="text-sm font-medium text-muted-foreground"> / day</span>
          </p>
          <div className="flex gap-2">
            <Button asChild variant="outline" size="sm">
              <Link to="/vehicles/$slug" params={{ slug: vehicle.slug }}>
                Details
              </Link>
            </Button>
            <Button asChild size="sm">
              <Link to="/vehicles/$slug" params={{ slug: vehicle.slug }}>
                Rent now
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </article>
  );
}
