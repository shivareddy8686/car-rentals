import { cn } from "@/lib/utils";
import { statusLabels } from "@/lib/riderent";

const tone: Record<string, string> = {
  available: "bg-success/12 text-success border-success/30",
  rented: "bg-warning/15 text-warning-foreground border-warning/40",
  maintenance: "bg-muted text-muted-foreground border-border",
  inactive: "bg-destructive/10 text-destructive border-destructive/30",
};

export function StatusBadge({
  status,
  className,
}: {
  status: string;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold",
        tone[status] ?? tone["inactive"],
        className,
      )}
    >
      <span className="size-1.5 rounded-full bg-current" aria-hidden="true" />
      {statusLabels[status] ?? status}
    </span>
  );
}
