import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { RentalLocation, VehicleCategory } from "@/lib/riderent";

function today() {
  return new Date().toISOString().slice(0, 10);
}

export function SearchWidget({
  categories,
  locations,
}: {
  categories: VehicleCategory[];
  locations: RentalLocation[];
}) {
  const navigate = useNavigate();
  const [pickup, setPickup] = useState("any");
  const [dropoff, setDropoff] = useState("any");
  const [category, setCategory] = useState("any");
  const [pickupDate, setPickupDate] = useState(today());
  const [returnDate, setReturnDate] = useState("");
  const [error, setError] = useState<string | null>(null);

  function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (returnDate && returnDate < pickupDate) {
      setError("The return date must be on or after the pickup date.");
      return;
    }
    setError(null);
    navigate({
      to: "/vehicles",
      search: {
        ...(category !== "any" ? { category } : {}),
        ...(pickup !== "any" ? { location: pickup } : {}),
      },
    });
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="surface-panel grid gap-4 p-5 md:grid-cols-2 lg:grid-cols-6 lg:items-end"
      aria-label="Search available vehicles"
    >
      <div className="space-y-1.5">
        <Label htmlFor="pickup-location">Pickup location</Label>
        <Select value={pickup} onValueChange={setPickup}>
          <SelectTrigger id="pickup-location">
            <SelectValue placeholder="Any city" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any city</SelectItem>
            {locations.map((location) => (
              <SelectItem key={location.id} value={location.slug}>
                {location.city} — {location.branch_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="return-location">Return location</Label>
        <Select value={dropoff} onValueChange={setDropoff}>
          <SelectTrigger id="return-location">
            <SelectValue placeholder="Same as pickup" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Same as pickup</SelectItem>
            {locations.map((location) => (
              <SelectItem key={location.id} value={location.slug}>
                {location.city} — {location.branch_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="pickup-date">Pickup date</Label>
        <Input
          id="pickup-date"
          type="date"
          min={today()}
          value={pickupDate}
          onChange={(event) => setPickupDate(event.target.value)}
        />
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="return-date">Return date</Label>
        <Input
          id="return-date"
          type="date"
          min={pickupDate || today()}
          value={returnDate}
          onChange={(event) => setReturnDate(event.target.value)}
        />
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="vehicle-type">Vehicle type</Label>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger id="vehicle-type">
            <SelectValue placeholder="All types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">All types</SelectItem>
            {categories.map((item) => (
              <SelectItem key={item.id} value={item.slug}>
                {item.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Button type="submit" size="lg" className="w-full">
        <Search className="size-4" aria-hidden="true" />
        Search
      </Button>

      {error ? (
        <p role="alert" className="text-sm text-destructive lg:col-span-6">
          {error}
        </p>
      ) : null}
    </form>
  );
}
