import { Link } from "@tanstack/react-router";
import { CarFront, Mail, Phone } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-border bg-sidebar text-sidebar-foreground">
      <div className="container-page grid gap-10 py-14 md:grid-cols-4">
        <div className="space-y-3">
          <span className="flex items-center gap-2.5">
            <span className="flex size-9 items-center justify-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground">
              <CarFront className="size-5" aria-hidden="true" />
            </span>
            <span className="text-base font-bold">RideRent</span>
          </span>
          <p className="text-sm text-sidebar-foreground/70">
            Rent the ride. Own the journey. Transparent daily rates on a well-maintained
            fleet across five Indian cities.
          </p>
        </div>

        <div className="space-y-3">
          <h2 className="text-sm font-semibold">Explore</h2>
          <ul className="space-y-2 text-sm text-sidebar-foreground/70">
            <li>
              <Link to="/vehicles" className="hover:text-sidebar-foreground">
                Browse vehicles
              </Link>
            </li>
            <li>
              <Link to="/locations" className="hover:text-sidebar-foreground">
                Pickup locations
              </Link>
            </li>
            <li>
              <Link to="/how-it-works" className="hover:text-sidebar-foreground">
                How it works
              </Link>
            </li>
            <li>
              <Link to="/about" className="hover:text-sidebar-foreground">
                About RideRent
              </Link>
            </li>
          </ul>
        </div>

        <div className="space-y-3">
          <h2 className="text-sm font-semibold">Support</h2>
          <ul className="space-y-2 text-sm text-sidebar-foreground/70">
            <li>
              <Link to="/contact" className="hover:text-sidebar-foreground">
                Contact us
              </Link>
            </li>
            <li>Rental agreement</li>
            <li>Insurance &amp; damage cover</li>
            <li>Cancellation policy</li>
          </ul>
        </div>

        <div className="space-y-3">
          <h2 className="text-sm font-semibold">Talk to us</h2>
          <ul className="space-y-2 text-sm text-sidebar-foreground/70">
            <li className="flex items-center gap-2">
              <Phone className="size-4" aria-hidden="true" /> +91 40 4512 8890
            </li>
            <li className="flex items-center gap-2">
              <Mail className="size-4" aria-hidden="true" /> support@riderent.example
            </li>
            <li>Support desk open 24/7</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-sidebar-border">
        <div className="container-page flex flex-col gap-2 py-5 text-xs text-sidebar-foreground/60 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} RideRent. Demo project — not a live rental service.</p>
          <p>Built as a full-stack portfolio project.</p>
        </div>
      </div>
    </footer>
  );
}
