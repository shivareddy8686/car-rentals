export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      bookings: {
        Row: {
          created_at: string
          days: number
          discount_total: number
          driver_name: string
          driver_phone: string
          end_date: string
          id: string
          insurance_total: number
          notes: string
          pickup_location_id: string | null
          price_per_day: number
          reference: string
          return_location_id: string | null
          start_date: string
          status: string
          tax_total: number
          total_amount: number
          updated_at: string
          user_id: string
          vehicle_id: string
        }
        Insert: {
          created_at?: string
          days: number
          discount_total?: number
          driver_name?: string
          driver_phone?: string
          end_date: string
          id?: string
          insurance_total?: number
          notes?: string
          pickup_location_id?: string | null
          price_per_day: number
          reference?: string
          return_location_id?: string | null
          start_date: string
          status?: string
          tax_total?: number
          total_amount: number
          updated_at?: string
          user_id: string
          vehicle_id: string
        }
        Update: {
          created_at?: string
          days?: number
          discount_total?: number
          driver_name?: string
          driver_phone?: string
          end_date?: string
          id?: string
          insurance_total?: number
          notes?: string
          pickup_location_id?: string | null
          price_per_day?: number
          reference?: string
          return_location_id?: string | null
          start_date?: string
          status?: string
          tax_total?: number
          total_amount?: number
          updated_at?: string
          user_id?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_pickup_location_id_fkey"
            columns: ["pickup_location_id"]
            isOneToOne: false
            referencedRelation: "locations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_return_location_id_fkey"
            columns: ["return_location_id"]
            isOneToOne: false
            referencedRelation: "locations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      locations: {
        Row: {
          address: string
          branch_name: string
          city: string
          contact_email: string
          contact_phone: string
          created_at: string
          id: string
          is_active: boolean
          opening_hours: string
          slug: string
          updated_at: string
        }
        Insert: {
          address: string
          branch_name: string
          city: string
          contact_email?: string
          contact_phone: string
          created_at?: string
          id?: string
          is_active?: boolean
          opening_hours?: string
          slug: string
          updated_at?: string
        }
        Update: {
          address?: string
          branch_name?: string
          city?: string
          contact_email?: string
          contact_phone?: string
          created_at?: string
          id?: string
          is_active?: boolean
          opening_hours?: string
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          full_name: string
          id: string
          phone: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          full_name?: string
          id: string
          phone?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          full_name?: string
          id?: string
          phone?: string
          updated_at?: string
        }
        Relationships: []
      }
      vehicle_categories: {
        Row: {
          created_at: string
          description: string
          display_order: number
          id: string
          name: string
          slug: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string
          display_order?: number
          id?: string
          name: string
          slug: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string
          display_order?: number
          id?: string
          name?: string
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      vehicles: {
        Row: {
          booking_count: number
          brand: string
          category_id: string
          created_at: string
          description: string
          doors: number
          features: string[]
          fuel_type: string
          has_air_conditioning: boolean
          has_gps: boolean
          id: string
          is_featured: boolean
          location_id: string | null
          manufacturing_year: number
          mileage: string
          model: string
          name: string
          price_per_day: number
          rating: number
          registration_number: string
          review_count: number
          seats: number
          slug: string
          status: string
          transmission: string
          updated_at: string
        }
        Insert: {
          booking_count?: number
          brand: string
          category_id: string
          created_at?: string
          description?: string
          doors?: number
          features?: string[]
          fuel_type: string
          has_air_conditioning?: boolean
          has_gps?: boolean
          id?: string
          is_featured?: boolean
          location_id?: string | null
          manufacturing_year: number
          mileage?: string
          model: string
          name: string
          price_per_day: number
          rating?: number
          registration_number: string
          review_count?: number
          seats: number
          slug: string
          status?: string
          transmission: string
          updated_at?: string
        }
        Update: {
          booking_count?: number
          brand?: string
          category_id?: string
          created_at?: string
          description?: string
          doors?: number
          features?: string[]
          fuel_type?: string
          has_air_conditioning?: boolean
          has_gps?: boolean
          id?: string
          is_featured?: boolean
          location_id?: string | null
          manufacturing_year?: number
          mileage?: string
          model?: string
          name?: string
          price_per_day?: number
          rating?: number
          registration_number?: string
          review_count?: number
          seats?: number
          slug?: string
          status?: string
          transmission?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicles_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "vehicle_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicles_location_id_fkey"
            columns: ["location_id"]
            isOneToOne: false
            referencedRelation: "locations"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      cancel_booking: { Args: { _booking_id: string }; Returns: undefined }
      create_booking: {
        Args: {
          _driver_name: string
          _driver_phone: string
          _end: string
          _notes?: string
          _pickup_location_id: string
          _return_location_id: string
          _start: string
          _vehicle_id: string
        }
        Returns: {
          created_at: string
          days: number
          discount_total: number
          driver_name: string
          driver_phone: string
          end_date: string
          id: string
          insurance_total: number
          notes: string
          pickup_location_id: string | null
          price_per_day: number
          reference: string
          return_location_id: string | null
          start_date: string
          status: string
          tax_total: number
          total_amount: number
          updated_at: string
          user_id: string
          vehicle_id: string
        }
        SetofOptions: {
          from: "*"
          to: "bookings"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      is_vehicle_available: {
        Args: { _end: string; _start: string; _vehicle_id: string }
        Returns: boolean
      }
      vehicle_booked_ranges: {
        Args: { _vehicle_id: string }
        Returns: {
          end_date: string
          start_date: string
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
