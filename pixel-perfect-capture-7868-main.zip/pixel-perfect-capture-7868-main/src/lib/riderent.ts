import { queryOptions } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import economyImg from "@/assets/cat-economy.jpg";
import sedanImg from "@/assets/cat-sedan.jpg";
import suvImg from "@/assets/cat-suv.jpg";
import luxuryImg from "@/assets/cat-luxury.jpg";
import electricImg from "@/assets/cat-electric.jpg";
import vanImg from "@/assets/cat-van.jpg";

export type VehicleCategory = {
  id: string;
  name: string;
  slug: string;
  description: string;
  display_order: number;
};

export type RentalLocation = {
  id: string;
  city: string;
  branch_name: string;
  slug: string;
  address: string;
  contact_phone: string;
  contact_email: string;
  opening_hours: string;
};

export type Vehicle = {
  id: string;
  name: string;
  slug: string;
  brand: string;
  model: string;
  category_id: string;
  location_id: string | null;
  registration_number: string;
  manufacturing_year: number;
  fuel_type: string;
  transmission: string;
  seats: number;
  doors: number;
  mileage: string;
  price_per_day: number;
  status: string;
  rating: number;
  review_count: number;
  booking_count: number;
  is_featured: boolean;
  has_air_conditioning: boolean;
  has_gps: boolean;
  description: string;
  features: string[];
  vehicle_categories: { name: string; slug: string } | null;
  locations: { city: string; branch_name: string; slug: string } | null;
};

const VEHICLE_SELECT =
  "*, vehicle_categories(name, slug), locations(city, branch_name, slug)";

const categoryImages: Record<string, string> = {
  economy: economyImg,
  sedan: sedanImg,
  suv: suvImg,
  luxury: luxuryImg,
  electric: electricImg,
  van: vanImg,
};

export function vehicleImage(categorySlug?: string | null) {
  return categoryImages[categorySlug ?? ""] ?? sedanImg;
}

export function formatPrice(value: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);
}

export const statusLabels: Record<string, string> = {
  available: "Available now",
  rented: "Currently rented",
  maintenance: "In maintenance",
  inactive: "Unavailable",
};

export const vehiclesQuery = queryOptions({
  queryKey: ["vehicles"],
  queryFn: async (): Promise<Vehicle[]> => {
    const { data, error } = await supabase
      .from("vehicles")
      .select(VEHICLE_SELECT)
      .order("is_featured", { ascending: false })
      .order("rating", { ascending: false });
    if (error) throw error;
    return (data ?? []) as unknown as Vehicle[];
  },
});

export const categoriesQuery = queryOptions({
  queryKey: ["vehicle_categories"],
  queryFn: async (): Promise<VehicleCategory[]> => {
    const { data, error } = await supabase
      .from("vehicle_categories")
      .select("id, name, slug, description, display_order")
      .order("display_order");
    if (error) throw error;
    return (data ?? []) as VehicleCategory[];
  },
});

export const locationsQuery = queryOptions({
  queryKey: ["locations"],
  queryFn: async (): Promise<RentalLocation[]> => {
    const { data, error } = await supabase
      .from("locations")
      .select(
        "id, city, branch_name, slug, address, contact_phone, contact_email, opening_hours",
      )
      .eq("is_active", true)
      .order("city");
    if (error) throw error;
    return (data ?? []) as RentalLocation[];
  },
});

export function vehicleQuery(slug: string) {
  return queryOptions({
    queryKey: ["vehicle", slug],
    queryFn: async (): Promise<Vehicle | null> => {
      const { data, error } = await supabase
        .from("vehicles")
        .select(VEHICLE_SELECT)
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw error;
      return (data ?? null) as unknown as Vehicle | null;
    },
  });
}

export type Booking = {
  id: string;
  reference: string;
  vehicle_id: string;
  start_date: string;
  end_date: string;
  days: number;
  price_per_day: number;
  insurance_total: number;
  discount_total: number;
  tax_total: number;
  total_amount: number;
  status: string;
  driver_name: string;
  driver_phone: string;
  notes: string;
  created_at: string;
  vehicles: {
    name: string;
    slug: string;
    brand: string;
    vehicle_categories: { slug: string; name: string } | null;
  } | null;
  pickup: { city: string; branch_name: string } | null;
  dropoff: { city: string; branch_name: string } | null;
};

const BOOKING_SELECT =
  "id, reference, vehicle_id, start_date, end_date, days, price_per_day, insurance_total, discount_total, tax_total, total_amount, status, driver_name, driver_phone, notes, created_at, vehicles(name, slug, brand, vehicle_categories(slug, name)), pickup:locations!bookings_pickup_location_id_fkey(city, branch_name), dropoff:locations!bookings_return_location_id_fkey(city, branch_name)";

export const bookingsQuery = queryOptions({
  queryKey: ["bookings"],
  queryFn: async (): Promise<Booking[]> => {
    const { data, error } = await supabase
      .from("bookings")
      .select(BOOKING_SELECT)
      .order("start_date", { ascending: false });
    if (error) throw error;
    return (data ?? []) as unknown as Booking[];
  },
});

export type Profile = { id: string; full_name: string; phone: string };

export const myProfileQuery = queryOptions({
  queryKey: ["profile"],
  queryFn: async (): Promise<Profile | null> => {
    const { data, error } = await supabase
      .from("profiles")
      .select("id, full_name, phone")
      .maybeSingle();
    if (error) throw error;
    return (data ?? null) as Profile | null;
  },
});

export type BookedRange = { start_date: string; end_date: string };

export function bookedRangesQuery(vehicleId: string | undefined) {
  return queryOptions({
    queryKey: ["booked_ranges", vehicleId],
    enabled: Boolean(vehicleId),
    queryFn: async (): Promise<BookedRange[]> => {
      if (!vehicleId) return [];
      const { data, error } = await supabase.rpc("vehicle_booked_ranges", {
        _vehicle_id: vehicleId,
      });
      if (error) throw error;
      return (data ?? []) as BookedRange[];
    },
  });
}

export function rangesOverlap(
  ranges: BookedRange[],
  start: string,
  end: string,
) {
  return ranges.some((range) => range.start_date <= end && range.end_date >= start);
}
