-- Profiles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
    COALESCE(NEW.raw_user_meta_data->>'phone', '')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Bookings
CREATE TABLE public.bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reference text NOT NULL UNIQUE DEFAULT 'RR' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8)),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  vehicle_id uuid NOT NULL REFERENCES public.vehicles(id) ON DELETE RESTRICT,
  pickup_location_id uuid REFERENCES public.locations(id) ON DELETE SET NULL,
  return_location_id uuid REFERENCES public.locations(id) ON DELETE SET NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  days integer NOT NULL,
  price_per_day numeric NOT NULL,
  insurance_total numeric NOT NULL DEFAULT 0,
  discount_total numeric NOT NULL DEFAULT 0,
  tax_total numeric NOT NULL DEFAULT 0,
  total_amount numeric NOT NULL,
  status text NOT NULL DEFAULT 'confirmed',
  driver_name text NOT NULL DEFAULT '',
  driver_phone text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX bookings_vehicle_dates_idx ON public.bookings (vehicle_id, start_date, end_date);
CREATE INDEX bookings_user_idx ON public.bookings (user_id);

GRANT SELECT, INSERT, UPDATE ON public.bookings TO authenticated;
GRANT ALL ON public.bookings TO service_role;

ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own bookings" ON public.bookings
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can create own bookings" ON public.bookings
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own bookings" ON public.bookings
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER trg_bookings_updated BEFORE UPDATE ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.validate_booking_dates()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.end_date < NEW.start_date THEN
    RAISE EXCEPTION 'Return date must be on or after the pick-up date';
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_bookings_validate BEFORE INSERT OR UPDATE ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.validate_booking_dates();

-- Availability check (does not expose other users' bookings)
CREATE OR REPLACE FUNCTION public.is_vehicle_available(_vehicle_id uuid, _start date, _end date)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT NOT EXISTS (
    SELECT 1 FROM public.bookings b
    WHERE b.vehicle_id = _vehicle_id
      AND b.status IN ('confirmed', 'active')
      AND b.start_date <= _end
      AND b.end_date >= _start
  ) AND EXISTS (
    SELECT 1 FROM public.vehicles v
    WHERE v.id = _vehicle_id AND v.status = 'available'
  );
$$;

GRANT EXECUTE ON FUNCTION public.is_vehicle_available(uuid, date, date) TO anon, authenticated;

-- Booked date ranges for a vehicle (dates only, no personal data)
CREATE OR REPLACE FUNCTION public.vehicle_booked_ranges(_vehicle_id uuid)
RETURNS TABLE (start_date date, end_date date)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT b.start_date, b.end_date
  FROM public.bookings b
  WHERE b.vehicle_id = _vehicle_id
    AND b.status IN ('confirmed', 'active')
    AND b.end_date >= current_date;
$$;

GRANT EXECUTE ON FUNCTION public.vehicle_booked_ranges(uuid) TO anon, authenticated;

-- Create booking with availability check
CREATE OR REPLACE FUNCTION public.create_booking(
  _vehicle_id uuid,
  _pickup_location_id uuid,
  _return_location_id uuid,
  _start date,
  _end date,
  _driver_name text,
  _driver_phone text,
  _notes text DEFAULT ''
)
RETURNS public.bookings
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _rate numeric;
  _days integer;
  _insurance numeric;
  _subtotal numeric;
  _discount numeric;
  _tax numeric;
  _total numeric;
  _row public.bookings;
BEGIN
  IF _uid IS NULL THEN
    RAISE EXCEPTION 'You must be signed in to book';
  END IF;

  IF _start < current_date THEN
    RAISE EXCEPTION 'Pick-up date cannot be in the past';
  END IF;

  IF _end < _start THEN
    RAISE EXCEPTION 'Return date must be on or after the pick-up date';
  END IF;

  SELECT price_per_day INTO _rate FROM public.vehicles WHERE id = _vehicle_id AND status = 'available';
  IF _rate IS NULL THEN
    RAISE EXCEPTION 'This vehicle is not available for booking';
  END IF;

  PERFORM 1 FROM public.bookings b
   WHERE b.vehicle_id = _vehicle_id
     AND b.status IN ('confirmed', 'active')
     AND b.start_date <= _end
     AND b.end_date >= _start
   FOR UPDATE;

  IF EXISTS (
    SELECT 1 FROM public.bookings b
    WHERE b.vehicle_id = _vehicle_id
      AND b.status IN ('confirmed', 'active')
      AND b.start_date <= _end
      AND b.end_date >= _start
  ) THEN
    RAISE EXCEPTION 'This vehicle is already booked for the selected dates';
  END IF;

  _days := (_end - _start) + 1;
  _insurance := 299 * _days;
  _subtotal := (_rate * _days) + _insurance;
  _discount := CASE WHEN _days >= 7 THEN round(_subtotal * 0.10, 2) ELSE 0 END;
  _tax := round((_subtotal - _discount) * 0.18, 2);
  _total := round(_subtotal - _discount + _tax, 2);

  INSERT INTO public.bookings (
    user_id, vehicle_id, pickup_location_id, return_location_id,
    start_date, end_date, days, price_per_day,
    insurance_total, discount_total, tax_total, total_amount,
    status, driver_name, driver_phone, notes
  ) VALUES (
    _uid, _vehicle_id, _pickup_location_id, _return_location_id,
    _start, _end, _days, _rate,
    _insurance, _discount, _tax, _total,
    'confirmed', COALESCE(_driver_name, ''), COALESCE(_driver_phone, ''), COALESCE(_notes, '')
  ) RETURNING * INTO _row;

  UPDATE public.vehicles SET booking_count = booking_count + 1 WHERE id = _vehicle_id;

  RETURN _row;
END;
$$;

GRANT EXECUTE ON FUNCTION public.create_booking(uuid, uuid, uuid, date, date, text, text, text) TO authenticated;

-- Cancel own booking
CREATE OR REPLACE FUNCTION public.cancel_booking(_booking_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.bookings
     SET status = 'cancelled'
   WHERE id = _booking_id
     AND user_id = auth.uid()
     AND status IN ('confirmed', 'active');
END;
$$;

GRANT EXECUTE ON FUNCTION public.cancel_booking(uuid) TO authenticated;