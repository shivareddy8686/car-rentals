CREATE TABLE public.vehicle_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  slug text NOT NULL UNIQUE,
  description text NOT NULL DEFAULT '',
  display_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.vehicle_categories TO anon, authenticated;
GRANT ALL ON public.vehicle_categories TO service_role;
ALTER TABLE public.vehicle_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Categories are publicly readable" ON public.vehicle_categories FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  city text NOT NULL,
  branch_name text NOT NULL,
  slug text NOT NULL UNIQUE,
  address text NOT NULL,
  contact_phone text NOT NULL,
  contact_email text NOT NULL DEFAULT '',
  opening_hours text NOT NULL DEFAULT '08:00 - 21:00',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.locations TO anon, authenticated;
GRANT ALL ON public.locations TO service_role;
ALTER TABLE public.locations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Locations are publicly readable" ON public.locations FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  brand text NOT NULL,
  model text NOT NULL,
  category_id uuid NOT NULL REFERENCES public.vehicle_categories(id) ON DELETE RESTRICT,
  location_id uuid REFERENCES public.locations(id) ON DELETE SET NULL,
  registration_number text NOT NULL UNIQUE,
  manufacturing_year integer NOT NULL,
  fuel_type text NOT NULL,
  transmission text NOT NULL,
  seats integer NOT NULL,
  doors integer NOT NULL DEFAULT 4,
  mileage text NOT NULL DEFAULT '',
  price_per_day numeric(10,2) NOT NULL,
  status text NOT NULL DEFAULT 'available',
  rating numeric(2,1) NOT NULL DEFAULT 0,
  review_count integer NOT NULL DEFAULT 0,
  booking_count integer NOT NULL DEFAULT 0,
  is_featured boolean NOT NULL DEFAULT false,
  has_air_conditioning boolean NOT NULL DEFAULT true,
  has_gps boolean NOT NULL DEFAULT true,
  description text NOT NULL DEFAULT '',
  features text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX vehicles_category_idx ON public.vehicles(category_id);
CREATE INDEX vehicles_location_idx ON public.vehicles(location_id);
CREATE INDEX vehicles_status_idx ON public.vehicles(status);
CREATE INDEX vehicles_price_idx ON public.vehicles(price_per_day);
GRANT SELECT ON public.vehicles TO anon, authenticated;
GRANT ALL ON public.vehicles TO service_role;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Vehicles are publicly readable" ON public.vehicles FOR SELECT TO anon, authenticated USING (true);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$
LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER trg_vehicle_categories_updated BEFORE UPDATE ON public.vehicle_categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_locations_updated BEFORE UPDATE ON public.locations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_vehicles_updated BEFORE UPDATE ON public.vehicles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.vehicle_categories (name, slug, description, display_order) VALUES
  ('Economy', 'economy', 'Light on fuel, easy to park and ideal for city errands.', 1),
  ('Sedan', 'sedan', 'Comfortable four-door rides for business trips and family travel.', 2),
  ('SUV', 'suv', 'High ground clearance and space for luggage-heavy road trips.', 3),
  ('Luxury', 'luxury', 'Premium interiors and refined driving for special occasions.', 4),
  ('Electric', 'electric', 'Zero tailpipe emissions with fast-charging convenience.', 5),
  ('Van', 'van', 'Seven seats and more for group travel and airport runs.', 6);

INSERT INTO public.locations (city, branch_name, slug, address, contact_phone, contact_email, opening_hours) VALUES
  ('Hyderabad', 'Gachibowli Hub', 'hyderabad-gachibowli', 'Plot 42, Financial District Road, Gachibowli, Hyderabad 500032', '+91 40 4512 8890', 'hyderabad@riderent.example', '06:00 - 23:00'),
  ('Bengaluru', 'Indiranagar Branch', 'bengaluru-indiranagar', '18, 100 Feet Road, Indiranagar, Bengaluru 560038', '+91 80 4123 7745', 'bengaluru@riderent.example', '07:00 - 22:00'),
  ('Mumbai', 'Andheri East Depot', 'mumbai-andheri-east', 'Unit 7, Chakala MIDC, Andheri East, Mumbai 400093', '+91 22 6789 1120', 'mumbai@riderent.example', '24 hours'),
  ('Delhi', 'Aerocity Terminal', 'delhi-aerocity', 'Level 1, Hospitality District, Aerocity, New Delhi 110037', '+91 11 4098 3312', 'delhi@riderent.example', '24 hours'),
  ('Pune', 'Baner Road Branch', 'pune-baner', '221, Baner Road, Pune 411045', '+91 20 6721 4408', 'pune@riderent.example', '07:00 - 21:30');

INSERT INTO public.vehicles (name, slug, brand, model, category_id, location_id, registration_number, manufacturing_year, fuel_type, transmission, seats, doors, mileage, price_per_day, status, rating, review_count, booking_count, is_featured, description, features)
SELECT v.name, v.slug, v.brand, v.model, c.id, l.id, v.reg, v.year, v.fuel, v.trans, v.seats, v.doors, v.mileage, v.price, v.status, v.rating, v.reviews, v.bookings, v.featured, v.descr, v.features
FROM (VALUES
  ('Maruti Suzuki Swift','maruti-suzuki-swift','Maruti Suzuki','Swift','economy','hyderabad-gachibowli','TS09EA1123',2023,'Petrol','Manual',5,4,'22 km/l',1450,'available',4.5,128,214,true,'A nimble hatchback that makes city driving effortless, with light steering and an easy 22 km/l average.',ARRAY['Bluetooth','USB charging','Rear parking sensors','ABS with EBD','Dual airbags']),
  ('Hyundai i20 Asta','hyundai-i20-asta','Hyundai','i20','economy','bengaluru-indiranagar','KA01MJ4477',2022,'Petrol','Manual',5,4,'20 km/l',1650,'available',4.4,96,168,false,'Premium hatchback with a well-insulated cabin, touchscreen infotainment and a comfortable ride.',ARRAY['Bluetooth','Apple CarPlay','Reverse camera','Cruise control','Dual airbags']),
  ('Tata Tiago XZ','tata-tiago-xz','Tata','Tiago','economy','pune-baner','MH12QP7781',2023,'Petrol','Manual',5,4,'23 km/l',1350,'available',4.2,74,131,false,'Budget-friendly and solidly built, a sensible choice for short city rentals.',ARRAY['Bluetooth','USB charging','Rear parking sensors','ABS with EBD']),
  ('Renault Kwid Climber','renault-kwid-climber','Renault','Kwid','economy','delhi-aerocity','DL3CBA9021',2022,'Petrol','Automatic',5,4,'21 km/l',1250,'maintenance',4.0,52,88,false,'Compact automatic with SUV-inspired styling and a surprisingly airy cabin.',ARRAY['Bluetooth','USB charging','Reverse camera','Dual airbags']),
  ('Toyota Camry Hybrid','toyota-camry-hybrid','Toyota','Camry','sedan','hyderabad-gachibowli','TS09FC2210',2023,'Hybrid','Automatic',5,4,'19 km/l',5400,'available',4.9,164,141,true,'A hushed executive sedan with hybrid efficiency, ventilated seats and limousine-like rear space.',ARRAY['Bluetooth','Apple CarPlay','GPS navigation','Cruise control','Reverse camera','Ventilated seats','9 airbags']),
  ('Honda City ZX','honda-city-zx','Honda','City','sedan','bengaluru-indiranagar','KA05NR8834',2023,'Petrol','Automatic',5,4,'18 km/l',2450,'available',4.6,142,236,true,'The dependable family sedan: smooth CVT, generous boot and a refined petrol engine.',ARRAY['Bluetooth','Apple CarPlay','GPS navigation','Cruise control','Reverse camera','Sunroof']),
  ('Skoda Slavia Style','skoda-slavia-style','Skoda','Slavia','sedan','mumbai-andheri-east','MH02DK5567',2023,'Petrol','Automatic',5,4,'17 km/l',2650,'available',4.5,61,94,false,'European road manners with a torquey turbo-petrol engine and confident highway stability.',ARRAY['Bluetooth','Wireless charging','GPS navigation','Cruise control','Reverse camera','Sunroof']),
  ('Volkswagen Virtus','volkswagen-virtus','Volkswagen','Virtus','sedan','pune-baner','MH14LC3390',2022,'Petrol','Automatic',5,4,'17 km/l',2550,'rented',4.4,58,102,false,'Planted, quiet and comfortable over long distances, with a spacious 521-litre boot.',ARRAY['Bluetooth','GPS navigation','Cruise control','Reverse camera','Dual-zone climate control']),
  ('Hyundai Creta SX','hyundai-creta-sx','Hyundai','Creta','suv','hyderabad-gachibowli','TS10GH4456',2023,'Diesel','Automatic',5,5,'17 km/l',3200,'available',4.7,187,312,true,'India''s favourite mid-size SUV: panoramic sunroof, plush seats and effortless diesel torque.',ARRAY['Bluetooth','Apple CarPlay','GPS navigation','Cruise control','Reverse camera','Panoramic sunroof','6 airbags']),
  ('Kia Seltos GTX','kia-seltos-gtx','Kia','Seltos','suv','bengaluru-indiranagar','KA03MM9912',2023,'Petrol','Automatic',5,5,'16 km/l',3350,'available',4.6,153,264,true,'Sharp styling, a crisp 10.25-inch display and a punchy turbo engine for weekend escapes.',ARRAY['Bluetooth','Apple CarPlay','GPS navigation','Cruise control','360 camera','Ventilated seats','Sunroof']),
  ('Toyota Fortuner 4x4','toyota-fortuner-4x4','Toyota','Fortuner','suv','delhi-aerocity','DL8CAF7702',2022,'Diesel','Automatic',7,5,'12 km/l',6900,'available',4.8,118,176,true,'Body-on-frame toughness with seven seats — built for hill routes and rough surfaces.',ARRAY['Bluetooth','GPS navigation','Cruise control','Reverse camera','4x4 drive','Hill assist','7 airbags']),
  ('Mahindra XUV700 AX7','mahindra-xuv700-ax7','Mahindra','XUV700','suv','pune-baner','MH12RS6634',2023,'Diesel','Automatic',7,5,'15 km/l',4100,'available',4.5,134,208,false,'Seven seats, dual widescreen displays and one of the safest cabins in its class.',ARRAY['Bluetooth','Apple CarPlay','GPS navigation','Adaptive cruise control','360 camera','Panoramic sunroof','7 airbags']),
  ('Tata Harrier Fearless','tata-harrier-fearless','Tata','Harrier','suv','mumbai-andheri-east','MH01BF2245',2023,'Diesel','Automatic',5,5,'16 km/l',3600,'available',4.4,88,142,false,'A commanding road presence with a comfortable, cushioned ride over city potholes.',ARRAY['Bluetooth','Apple CarPlay','GPS navigation','Cruise control','360 camera','Ventilated seats']),
  ('Jeep Compass Limited','jeep-compass-limited','Jeep','Compass','suv','delhi-aerocity','DL4CBC8890',2022,'Diesel','Automatic',5,5,'15 km/l',3900,'rented',4.3,71,118,false,'Rugged, well-finished and surefooted, with a cabin that feels a class above.',ARRAY['Bluetooth','GPS navigation','Cruise control','Reverse camera','All-wheel drive','Hill assist']),
  ('BMW 3 Series 330i','bmw-3-series-330i','BMW','3 Series','luxury','hyderabad-gachibowli','TS07JK1188',2023,'Petrol','Automatic',5,4,'14 km/l',11500,'available',4.9,74,86,true,'A driver''s sedan with sharp steering, a 258 bhp turbo engine and a beautifully trimmed cabin.',ARRAY['Bluetooth','Apple CarPlay','GPS navigation','Adaptive cruise control','360 camera','Harman Kardon audio','Ventilated seats']),
  ('Mercedes-Benz C-Class','mercedes-benz-c-class','Mercedes-Benz','C-Class','luxury','mumbai-andheri-east','MH02EK4412',2023,'Petrol','Automatic',5,4,'13 km/l',12800,'available',4.9,66,74,true,'Chauffeur-grade comfort with an 11.9-inch portrait display and pillow-soft rear seats.',ARRAY['Bluetooth','GPS navigation','Adaptive cruise control','360 camera','Burmester audio','Panoramic sunroof','Ambient lighting']),
  ('Audi A4 Premium Plus','audi-a4-premium-plus','Audi','A4','luxury','delhi-aerocity','DL9CAX5521',2022,'Petrol','Automatic',5,4,'14 km/l',10900,'available',4.7,58,69,false,'Understated luxury with Virtual Cockpit instrumentation and a whisper-quiet ride.',ARRAY['Bluetooth','Apple CarPlay','GPS navigation','Cruise control','Reverse camera','Bang & Olufsen audio']),
  ('Volvo XC40 Ultimate','volvo-xc40-ultimate','Volvo','XC40','luxury','bengaluru-indiranagar','KA51MN7734',2023,'Petrol','Automatic',5,5,'14 km/l',9800,'maintenance',4.6,44,52,false,'Scandinavian design with class-leading safety tech and superb front seats.',ARRAY['Bluetooth','GPS navigation','Adaptive cruise control','360 camera','Harman Kardon audio','Panoramic sunroof']),
  ('Tesla Model 3 Long Range','tesla-model-3-long-range','Tesla','Model 3','electric','bengaluru-indiranagar','KA02EV3311',2023,'Electric','Automatic',5,4,'560 km range',9500,'available',4.8,92,104,true,'Silent, instant acceleration with over 500 km of real-world range and over-the-air updates.',ARRAY['Autopilot','GPS navigation','Glass roof','Premium audio','Fast charging','Sentry mode']),
  ('Tata Nexon EV Max','tata-nexon-ev-max','Tata','Nexon EV','electric','pune-baner','MH12EV8842',2023,'Electric','Automatic',5,5,'420 km range',3400,'available',4.4,81,148,false,'A practical electric compact SUV with quick charging and near-zero running costs.',ARRAY['Bluetooth','Apple CarPlay','GPS navigation','Cruise control','Reverse camera','Fast charging']),
  ('MG ZS EV Exclusive','mg-zs-ev-exclusive','MG','ZS EV','electric','hyderabad-gachibowli','TS08EV6690',2022,'Electric','Automatic',5,5,'460 km range',4200,'available',4.3,63,97,false,'Smooth, silent motoring with a panoramic sunroof and generous equipment list.',ARRAY['Bluetooth','GPS navigation','Cruise control','360 camera','Panoramic sunroof','Fast charging']),
  ('Toyota Innova Crysta','toyota-innova-crysta','Toyota','Innova Crysta','van','mumbai-andheri-east','MH03CD1109',2022,'Diesel','Manual',7,5,'14 km/l',3800,'available',4.7,201,388,true,'The go-to people mover for group travel — unburstable, comfortable and huge inside.',ARRAY['Bluetooth','GPS navigation','Rear AC vents','Reverse camera','Captain seats']),
  ('Kia Carens Luxury Plus','kia-carens-luxury-plus','Kia','Carens','van','delhi-aerocity','DL1CAK4478',2023,'Diesel','Automatic',7,5,'17 km/l',3100,'available',4.4,97,162,false,'Seven seats with car-like handling and a third row adults can actually use.',ARRAY['Bluetooth','Apple CarPlay','GPS navigation','Cruise control','Reverse camera','Rear AC vents'])
) AS v(name, slug, brand, model, cat_slug, loc_slug, reg, year, fuel, trans, seats, doors, mileage, price, status, rating, reviews, bookings, featured, descr, features)
JOIN public.vehicle_categories c ON c.slug = v.cat_slug
JOIN public.locations l ON l.slug = v.loc_slug;